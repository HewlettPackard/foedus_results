for i in 1 2 3; do
  for w in 10; do #1 2 3 4 5 6 7 8 9 10; do
    echo $i, $w
    ./run.sh ./out-perf.masstree/benchmarks/dbtest ycsb 224 10 "--null-log-device --tmpfs-dir=/dev/shm/tzwang/ermia-tmpfs --prefault-gig=80 --node-memory-gb=50" "--rmw-additional-reads=`expr 10 - $w` --reps-per-tx=$w --initial-table-size=50" &> SI_SSN-ycsb-rw-gh.w$w.r$i
  done
done
