for i in 1 2 3 4 5 6 7 8 9 10; do
  echo $i
  ./run.sh  ./out-perf.masstree/benchmarks/dbtest ycsb 12 10 "--null-log-device --tmpfs-dir=/dev/shm/tzwang/ermia-tmpfs --prefault-gig=40 --node-memory-gb=4" "--rmw-additional-reads=10 --reps-per-tx=0 --initial-table-size=50" &> SI_SSN-ycsb-ro-z820.no-htt.t12.r$i
done
