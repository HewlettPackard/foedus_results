for th in 2 4; do 
  for i in 1 2 3 4 5 6 7 8 9 10; do 
    echo $th $i
    ./run.sh ./out-perf.masstree/benchmarks/dbtest ycsb $th 10 "--null-log-device --prefault-gig=1 --node-memory-gb=1 --tmpfs-dir=/dev/shm/tzwang/ermia-tmpfs" "--initial-table-size=50 --reps-per-tx=0 --rmw-additional-reads=10" &> SI_SSN-ycsb-50-hp840-t$th.w0.r$i
  done
done
