loggers_per_node=1
volatile_pool_size=1
snapshot_pool_size=1
reducer_buffer_size=1
duration_micro=10000000
thread_per_node=4
numa_nodes=1
log_buffer_mb=128
machine_name="HP840"
machine_shortname="lp"
fork_workers=true
null_log_device=true
high_priority=false # To set this to true, you must add "yourname - rtprio 99" to limits.conf

for hot_threshold in 0 256 50 100; do
  for size in 50 1000 10000; do
    for theta in 0; do
      for addread in 10; do
        . config_ycsb_f.sh $theta $addread `expr 10 - $addread` $size $hot_threshold
        . run_common.sh
      done
    done
  done
done
