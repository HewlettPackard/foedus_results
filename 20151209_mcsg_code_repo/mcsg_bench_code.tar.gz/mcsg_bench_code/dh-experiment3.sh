dir="`date +%F`-dh"
mkdir -p $dir
for b in "compact" # "sparse" #"compact" #"sparse"
do
  for w in 0 #0 #1000
  do
    for algo in mcsg mcsg++ mcsg+ #mcsg++ #mcsg tatas k42 c_mcsg_mcs #mcsb mcsg+
    do
      for guests in 1 #2 4 8 15 30 60 90 120
      do
        for pi in 100 #-1
        do
          for tkt in 100 # Run MCSg+ with this, to have consistent file names. Also plot-exp3.sh will create symlinks to fake Mcsg+ with MCSg++ with tkt=-1. So don't run MCSg+ with tkt=-1.
          do
            for rep in 0 1 2 3 4
            do
              echo "pi cycle=$pi, tkt cycle=$tkt, wait=$w us, bind=$b, algo=$algo, guests=$guests, rep=$rep..."
              ./mcsg_bench -lock $algo -guests $guests -workers `expr 240 - $guests` -worker_delay=$w -guest_delay=$w -mcsgpp_pi_cycle=$pi -mcsgpp_tkt_cycle=$tkt -core_bind=$b -duration=10 &> "$dir/exp3.wc-$w.pc-$pi.tc-$tkt.bind-$b.$algo.$guests.$rep"
            done
          done
        done
      done
    done
  done
done
