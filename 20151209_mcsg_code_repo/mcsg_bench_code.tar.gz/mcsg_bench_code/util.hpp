/*
 * Copyright (c) 2014-2015, Hewlett-Packard Development Company, LP.
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details. You should have received a copy of the GNU General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * HP designates this particular file as subject to the "Classpath" exception
 * as provided by HP in the LICENSE.txt file that accompanied this code.
 */
#ifndef UTIL_HPP_
#define UTIL_HPP_

#include <stdint.h>
#include <valgrind.h>

#include <cassert>
#include <thread>

#include "rdtsc.hpp"

#define LIKELY(x)      __builtin_expect(!!(x), 1)
#define UNLIKELY(x)    __builtin_expect(!!(x), 0)

/** Spin locally while the given condition holds */
template <typename COND>
inline void spin_while(COND spin_while_cond) {
//  uint64_t spins = 0;
  while (spin_while_cond()) {
/* these do slow down even not on valgrind. redundant instructions?
    ++spins;
    if (RUNNING_ON_VALGRIND && (spins & 0xF) == 0) {
      std::this_thread::yield();
    }
*/
  }
}

/**
 * Basically same as above, but we check the cond per the given number of cycles.
 * This is used where we don't want to evaluate COND so often.
 */
template <typename COND>
inline void poll_while(COND cond, uint64_t poll_cycles) {
  if (poll_cycles == 0) {
    spin_while<COND>(cond);
    return;
  } else {
    while (cond()) {
      wait_rdtsc_cycles(poll_cycles);
    }
  }
}

/**
 * Basically same as above, but we check the cond per the given number of cycles.
 * This is used where we don't want to evaluate COND so often.
 */
template <typename COND>
inline void poll_bo_while(COND cond, uint64_t initial_loops=2) {
  //const uint64_t kInitialLoops = 32;
  const uint64_t kMaxLoops = 1ULL << 20;  // probably 1<<22 cycles or something
  const uint64_t kMultiplier = 2;
  volatile uint64_t counter = 0;
  uint64_t loops = initial_loops;
  while (true) {
    if (!cond()) {
      return;
    }
    counter = 0;
    while (LIKELY(counter < loops)) {
      ++counter;
    }
    loops *= kMultiplier;
    loops = std::min(loops, kMaxLoops);
  }
}

/**
 * Busy-wait loop that uses high-resolution timer.
 * This should be not affected by RDTSC-related issues,
 * but instead has higher cost of high-reso timer.
 * As far as the wait-time is several microseconds, it should be fine.
 */
void wait_timer_microseconds(uint64_t microsec);

/**
 * We often can't see what the value was when we do "assert(var.load() == 123)".
 * This method would solve it, and of course completely go away in release compilation.
 */
template <typename T>
inline void assert_equal(T op, T expected) {
  assert(op == expected);
}
template <typename T>
inline void assert_notequal(T op, T expected) {
  assert(op != expected);
}
template <typename T>
inline void assert_equal_or(T op, T expected1, T expected2) {
  assert(op == expected1 || op == expected2);
}

/// NOTE: do NOT directly use the functions above. If you do that, functions with by-effects
/// will not be eliminated. Use the macros below.
#ifdef NDEBUG
// tricks to completely eliminate the content of x/y/etc in release compilation.
#define ASSERT_EQUAL(x, y) do { (void) sizeof(x); (void) sizeof(y); } while (0)
#define ASSERT_NOTEQUAL(x, y) do { (void) sizeof(x); (void) sizeof(y); } while (0)
#define ASSERT_EQUAL_OR(x, y, z) do { (void) sizeof(x); (void) sizeof(y); (void) sizeof(z); } while (0)
#else  // NDEBUG
#define ASSERT_EQUAL(x, y) assert_equal(x, y)
#define ASSERT_NOTEQUAL(x, y) assert_notequal(x, y)
#define ASSERT_EQUAL_OR(x, y, z) assert_equal_or(x, y, z)
#endif  // NDEBUG


/**
 * @brief A very simple and deterministic random generator that is more aligned with standard
 * benchmark such as TPC-C.
 * @ingroup ASSORTED
 * @details
 * Actually this is exactly from TPC-C spec.
 */
class UniformRandom {
 public:
  UniformRandom() : seed_(0) {}
  explicit UniformRandom(uint64_t seed) : seed_(seed) {}

  uint32_t uniform_upto(uint32_t to) {
    return next_uint32() % to;
  }

  uint64_t get_current_seed() {
    return seed_;
  }
  void set_current_seed(uint64_t seed) {
    seed_ = seed;
  }

  uint64_t next_uint64() {
    return (static_cast<uint64_t>(next_uint32()) << 32) | next_uint32();
  }
  uint32_t next_uint32() {
    seed_ = seed_ * 0xD04C3175 + 0x53DA9022;
    return (seed_ >> 32) ^ (seed_ & 0xFFFFFFFF);
  }

 private:
  uint64_t seed_;
};

#endif  // UTIL_HPP_
