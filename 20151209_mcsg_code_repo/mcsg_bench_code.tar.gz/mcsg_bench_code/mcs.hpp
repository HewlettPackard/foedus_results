/*
 * Copyright (c) 2014-2015, Hewlett-Packard Development Company, LP.
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details. You should have received a copy of the GNU General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * HP designates this particular file as subject to the "Classpath" exception
 * as provided by HP in the LICENSE.txt file that accompanied this code.
 */
#ifndef MCS_HPP_
#define MCS_HPP_

#include <numa.h>

#include <atomic>
#include <cassert>
#include <cstring>
#include <iostream>
#include <memory>

#include "lock_api.hpp"
#include "util.hpp"

typedef uint64_t McsNodeInt;  // used as std::atomic containee

constexpr uint16_t kNullSocket = 0xFFFFU;
constexpr uint16_t kNullThread = 0xFFFFU;

struct McsNode {
  constexpr McsNode()
    : socket_(kNullSocket),
      thread_(kNullThread),
      qnode_index_(0) {}
  constexpr McsNode(uint16_t socket, uint16_t thread)
    : socket_(socket),
      thread_(thread),
      qnode_index_(0) {}
  constexpr McsNode(uint16_t socket, uint16_t thread, uint32_t qnode_index)
    : socket_(socket),
      thread_(thread),
      qnode_index_(qnode_index) {}

  bool is_null() const {
    return socket_ == kNullSocket;
  }

  uint16_t socket_;
  uint16_t thread_;  // in-socket index of the worker
  /** Used only in cohort locks. otherwise 0. */
  uint32_t qnode_index_;
};

union McsNodeUnion {
  constexpr McsNodeUnion() : component() {}
  constexpr McsNodeUnion(uint16_t socket, uint16_t thread) : component(socket, thread) {}
  constexpr McsNodeUnion(uint16_t socket, uint16_t thread, uint32_t qnode_index)
    : component(socket, thread, qnode_index) {}

  McsNodeInt word;
  McsNode component;
};

const McsNodeInt kNullMcsNodeInt = McsNodeUnion().word;

inline McsNode from_int(McsNodeInt word) {
  McsNodeUnion tmp;
  tmp.word = word;
  return tmp.component;
}

/** McsNode in its own cacheline */
struct FatMcsNode {
  std::atomic< McsNodeInt > node_;
  /** Used only in cohort locks */
  std::atomic< McsNodeInt > local_node_;
  // 4 cachelines to prevent even HW-prefetching
  char filler_[256 - sizeof(node_) - sizeof(local_node_)];
};

enum class McsThreadStatus : uint32_t {
  /** Not waiting for any other thread. Either not joining the lock or holds the ownership */
  kRunning = 0U,
  /** Waiting for a predecessor */
  kWaiting = 1U,
  /**
   * Used only in cohort locks.
   * This thread has inherited the ownership of global lock from predecessor
   * (or, "local release"). Thus, it can skip going on to the global lock.
   */
  kGlobalInherited = 2U,
  /**
   * Used only in cohort locks.
   * This thread has been waken up by predecessor, but didn't inherit the ownership of global lock.
   * Thus, it has to join the global lock.
   */
  kGlobalContested = 3U,
};

/** Just a boolean flag per thread.... it was. now it contains many more */
struct FatMcsThreadStatus {
  std::atomic< McsThreadStatus > status_;
  /**
   * Used only in cohort locks.
   * How many predecessors inherited the lock without contesting at global lock.
   */
  std::atomic<uint32_t>         inherit_count_;
  /**
   * Used only in cohort locks.
   * Tells the location of the qnode the predecessor installed to the global lock.
   */
  std::atomic<McsNodeInt>       inherited_qnode_;
  // 4 cachelines to prevent even HW-prefetching
  char filler_[256 - sizeof(McsThreadStatus) - sizeof(uint32_t) - sizeof(inherited_qnode_)];

  void init() {
    status_.store(McsThreadStatus::kRunning);
    inherit_count_.store(0);
  }
  void spin_while_waiting() const {
    spin_while([this]{
      return status_.load(std::memory_order_acquire) == McsThreadStatus::kWaiting;
    });
  }
  bool is_waiting() const {
    return status_.load(std::memory_order_acquire) == McsThreadStatus::kWaiting;
  }
  void set_waiting(std::memory_order barrier) {
    return status_.store(McsThreadStatus::kWaiting, barrier);
  }
  void set_running(std::memory_order barrier) {
    return status_.store(McsThreadStatus::kRunning, barrier);
  }
};

/**
 * Base class for all MCS implementations.
 * This class is just to define the common code, not the behavior (interface).
 * No virtual method!
 */
struct McsBase {
  int init_base(
    uint16_t socket_count,
    uint16_t in_socket_worker_count,
    uint32_t total_worker_count) {
    socket_count_ = socket_count;
    in_socket_worker_count_ = in_socket_worker_count;
    total_worker_count_ = total_worker_count;
    tail_.store(kNullMcsNodeInt);
    qnodes_array_auto_release_.reset(new FatMcsNode*[socket_count]);
    qnodes_ = qnodes_array_auto_release_.get();
    statuses_array_auto_release_.reset(new FatMcsThreadStatus*[socket_count]);
    statuses_ = statuses_array_auto_release_.get();
    for (auto socket = 0; socket < socket_count; ++socket) {
      qnodes_[socket] = reinterpret_cast<FatMcsNode*>(
        ::numa_alloc_onnode(sizeof(FatMcsNode) * in_socket_worker_count, socket));
      std::memset(qnodes_[socket], 0, sizeof(FatMcsNode) * in_socket_worker_count);
      statuses_[socket] = reinterpret_cast<FatMcsThreadStatus*>(
        ::numa_alloc_onnode(sizeof(FatMcsThreadStatus) * in_socket_worker_count, socket));
      std::memset(statuses_[socket], 0, sizeof(FatMcsThreadStatus) * in_socket_worker_count);
      for (auto thread_index = 0; thread_index < in_socket_worker_count; ++thread_index) {
        qnodes_[socket][thread_index].node_.store(kNullMcsNodeInt);
        qnodes_[socket][thread_index].local_node_.store(kNullMcsNodeInt);
        statuses_[socket][thread_index].init();
      }
    }
    return 0;
  }

  int uninit_base() {
    if (qnodes_) {
      for (auto socket = 0; socket < socket_count_; ++socket) {
        if (qnodes_[socket]) {
          ::numa_free(qnodes_[socket], sizeof(FatMcsNode) * in_socket_worker_count_);
          qnodes_[socket] = nullptr;
        }
      }
      qnodes_array_auto_release_.reset(nullptr);
      qnodes_ = nullptr;
    }

    if (statuses_) {
      for (auto socket = 0; socket < socket_count_; ++socket) {
        if (statuses_[socket]) {
          ::numa_free(statuses_[socket], sizeof(FatMcsThreadStatus) * in_socket_worker_count_);
          statuses_[socket] = nullptr;
        }
      }
      statuses_array_auto_release_.reset(nullptr);
      statuses_ = nullptr;
    }
    return 0;
  }

  std::atomic< McsNodeInt > tail_;
  char separator_[256 - sizeof(std::atomic< McsNodeInt >)];


  uint16_t socket_count_;
  uint16_t in_socket_worker_count_;
  uint32_t total_worker_count_;

  /**
   * qnodes[socket][thread] is the QNode of the specified thread.
   * qnodes[socket] is an array allocated in the socket using libnuma.
   */
  FatMcsNode** qnodes_;
  std::unique_ptr< FatMcsNode*[] > qnodes_array_auto_release_;

  /** waiting_ bool flag for each thread. similar to above */
  FatMcsThreadStatus** statuses_;
  std::unique_ptr< FatMcsThreadStatus*[] > statuses_array_auto_release_;
};

/**
 * Basic MCS lock.
 */
struct Mcs : public McsBase {
  /**
   * Must have a constructor without arguments.
   */
  Mcs() {}
  /** We recommend disabling copy constructor to prevent misuse */
  Mcs(const Mcs& other) = delete;

  /** @returns a unique name that describes the lock algorithm */
  static std::string name() { return "mcs"; }

  /**
   * Do whatever initialization required to run the experiment.
   * @return will be the return value of main() unless it's 0 (no error).
   */
  int init(
    uint16_t socket_count,
    uint16_t in_socket_worker_count,
    uint32_t total_worker_count) {
    return init_base(socket_count, in_socket_worker_count, total_worker_count);
  }

  /**
   * Do whatever un-initialization after the experiment.
   * @return will be the return value of main() unless it's 0 (no error).
   */
  int uninit() {
    return uninit_base();
  }

  /**
   * Unconditional lock-acquire on lock_index for regular user with the given indexes.
   */
  void regular_acquire(
    uint16_t socket_index,
    uint16_t in_socket_worker_index) __attribute__((always_inline));

  /**
   * Lock-release for regular user.
   */
  void regular_release(
    uint16_t socket_index,
    uint16_t in_socket_worker_index) __attribute__((always_inline));

  /**
   * Unconditional lock-acquire on lock_index for guest user with the given fingerprint
   * (which semi-identifies the guest thread. it might not be unique).
   */
  void guest_acquire(
    uint32_t guest_fingerprint) __attribute__((always_inline));

  /**
   * Lock-release for guest user.
   */
  void guest_release(
    uint32_t guest_fingerprint) __attribute__((always_inline));

  /** Print out whatever statistics collected during the experiment. */
  void print_stat() {
  }
};

inline void Mcs::regular_acquire(
  uint16_t socket_index,
  uint16_t in_socket_worker_index) {
  std::atomic< McsNodeInt >* me = &qnodes_[socket_index][in_socket_worker_index].node_;
  auto* me_status = &statuses_[socket_index][in_socket_worker_index];
  // assert(!me_status->is_waiting());

  // me_status->set_waiting(std::memory_order_release);
  me->store(kNullMcsNodeInt, std::memory_order_release);

  McsNodeInt my_node_word = McsNodeUnion(socket_index, in_socket_worker_index).word;
  McsNodeUnion prev_node;
  prev_node.word = tail_.exchange(my_node_word);
  assert(prev_node.word != my_node_word);
  if (prev_node.component.is_null()) {
    // me_status->set_running(std::memory_order_release);
    assert(tail_.load() != kNullMcsNodeInt);
    return;
  }

  // assert(me_status->is_waiting());
  assert(tail_.load() != kNullMcsNodeInt);
  const uint16_t pred_socket = prev_node.component.socket_;
  const uint16_t pred_thread = prev_node.component.thread_;
  assert(pred_socket < socket_count_);
  assert(pred_thread < in_socket_worker_count_);
  assert(pred_socket != socket_index || pred_thread != in_socket_worker_index);
  std::atomic< McsNodeInt >* predecessor = &qnodes_[pred_socket][pred_thread].node_;
  assert(predecessor->load() == kNullMcsNodeInt);
  me_status->set_waiting(std::memory_order_release);
  predecessor->store(my_node_word, std::memory_order_release);

  me_status->spin_while_waiting();
  assert(!me_status->is_waiting());
  assert(tail_.load() != kNullMcsNodeInt);
}

inline void Mcs::regular_release(
  uint16_t socket_index,
  uint16_t in_socket_worker_index) {
  std::atomic< McsNodeInt >* me = &qnodes_[socket_index][in_socket_worker_index].node_;
  assert(!statuses_[socket_index][in_socket_worker_index].is_waiting());
  const McsNodeInt myself = McsNodeUnion(socket_index, in_socket_worker_index).word;

  McsNodeInt my_node = me->load(std::memory_order_acquire);
  assert(my_node != myself);
  if (my_node == kNullMcsNodeInt) {
    McsNodeInt expected = myself;
    if (tail_.compare_exchange_strong(expected, kNullMcsNodeInt)) {
      return;
    }

    assert(expected != kNullMcsNodeInt);
    assert(expected != myself);

    spin_while([me]{ return me->load(std::memory_order_acquire) == kNullMcsNodeInt; });
    my_node = me->load(std::memory_order_acquire);
  }

  assert(my_node != kNullMcsNodeInt);

  assert(tail_.load() != kNullMcsNodeInt);
  assert(!statuses_[socket_index][in_socket_worker_index].is_waiting());

  McsNodeUnion my_node_union;
  my_node_union.word = my_node;
  const uint16_t socket = my_node_union.component.socket_;
  const uint16_t thread = my_node_union.component.thread_;
  assert(socket < socket_count_);
  assert(thread < in_socket_worker_count_);
  assert(socket != socket_index || thread != in_socket_worker_index);
  auto* successor_status = &statuses_[socket][thread];
  assert(successor_status->is_waiting());
  successor_status->set_running(std::memory_order_release);
}

inline void Mcs::guest_acquire(uint32_t /*guest_fingerprint*/) {
  std::cerr << "MCS doesn't support guest-lock" << std::endl;
  std::exit(1);
}

inline void Mcs::guest_release(uint32_t /*guest_fingerprint*/) {
  std::cerr << "MCS doesn't support guest-lock" << std::endl;
  std::exit(1);
}

#endif  // MCS_HPP_
