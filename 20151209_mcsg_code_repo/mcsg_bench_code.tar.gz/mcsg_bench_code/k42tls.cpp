/*
 * Copyright (c) 2014-2015, Hewlett-Packard Development Company, LP.
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details. You should have received a copy of the GNU General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * HP designates this particular file as subject to the "Classpath" exception
 * as provided by HP in the LICENSE.txt file that accompanied this code.
 */
#include "k42tls.hpp"

struct K42NodePool {
  enum Constant {
    /**
     * this pool so far doesn't support a dynamic expansion.
     * in our experiment we just statically allocate a fixed size array
     */
    kMaxPoolSize = 1 << 12,
  };

  K42TlsNode pool_[kMaxPoolSize];
  std::atomic<uint32_t> borrowed_count_;

  K42NodePool() {
    // Starts from 3 (avoid kK42TlsNull/kK42TlsWaiting/Sentinel)
    borrowed_count_ = 3;
  }
  K42TlsIndex borrow()  __attribute__((always_inline));
  K42TlsNode* deferefence(K42TlsIndex index)  __attribute__((always_inline));
  // no support for "return" so far. our experiment doesn't need it
};

__thread K42TlsIndex tls_borrowed_qnode_index;

/**
 * This is the instance of "shared" qnode pool.
 * Conceptually it's on shared-memory for multi-process, but in this experiment
 * it's just a global variable.
 */
K42NodePool global_qnode_pool;

K42TlsIndex K42Tls::borrow_tls_qnode() {
  if (tls_borrowed_qnode_index != kK42TlsNull) {
    return tls_borrowed_qnode_index;
  }

  tls_borrowed_qnode_index = global_qnode_pool.borrow();
  return tls_borrowed_qnode_index;
}

K42TlsNode* K42Tls::dereference_qnode(K42TlsIndex index) {
  assert(index != kK42TlsNull);
  assert(index != kK42TlsWaiting);
  assert(index < K42NodePool::kMaxPoolSize);
  if (index == kK42TlsSentinel) {
    return &lock_;
  }
  return global_qnode_pool.deferefence(index);
}

K42TlsIndex K42NodePool::borrow() {
  uint32_t my_index = borrowed_count_.fetch_add(1U);
  assert(my_index < kMaxPoolSize);
  pool_[my_index].next_ = kK42TlsNull;
  pool_[my_index].tail_ = kK42TlsNull;
  return my_index;
}
K42TlsNode* K42NodePool::deferefence(K42TlsIndex index)  {
  return pool_ + index;
}

void K42Tls::guest_acquire(uint32_t /*guest_fingerprint*/) {
retry:
  K42TlsIndex pred = lock_.tail_.load(std::memory_order_acquire);
  if (pred == kK42TlsNull) {
    K42TlsIndex expected = kK42TlsNull;
    if (!lock_.tail_.compare_exchange_weak(expected, kK42TlsSentinel)) {
      goto retry;
    }
  } else {
    K42TlsIndex my_index = borrow_tls_qnode();
    K42TlsNode* my_node = dereference_qnode(my_index);
    my_node->next_.store(kK42TlsNull, std::memory_order_release);
    my_node->tail_.store(kK42TlsWaiting, std::memory_order_release);
    if (!lock_.tail_.compare_exchange_weak(pred, my_index)) {
      goto retry;
    }
    K42TlsNode* pred_node = dereference_qnode(pred);
    pred_node->next_.store(my_index, std::memory_order_release);
    while (my_node->tail_.load(std::memory_order_acquire) == kK42TlsWaiting) {}
    // Now I have the lock. Capture the successor (if any) and send
    // it to the lock's next field. After this my QNode can be discarded.
    K42TlsIndex successor = my_node->next_.load(std::memory_order_acquire);
    if (successor) {
      K42TlsNode* successor_node = dereference_qnode(successor);
      lock_.next_.store(successor, std::memory_order_release);
    } else {
      // Make the lock point to itself
      K42TlsIndex expected = my_index;
      lock_.next_.store(kK42TlsNull, std::memory_order_release);
      if (!lock_.tail_.compare_exchange_weak(expected, kK42TlsSentinel)) {
        // Somebody else got in, but it should queue up after me
        do {
          successor = my_node->next_.load(std::memory_order_acquire);
        } while (successor == kK42TlsNull);
        assert(successor != kK42TlsNull && successor != kK42TlsWaiting);
        lock_.next_.store(successor, std::memory_order_release);
      }
    }
  }
}

void K42Tls::guest_release(uint32_t /*guest_fingerprint*/) {
  K42TlsIndex succ = lock_.next_.load(std::memory_order_acquire);
  if (succ == kK42TlsNull) {
    K42TlsIndex expected = kK42TlsSentinel;
    if (lock_.tail_.compare_exchange_weak(expected, kK42TlsNull)) {
      return;
    } else {
      do {
        succ = lock_.next_.load(std::memory_order_acquire);
      } while (!succ);
    }
  }
  K42TlsNode* succ_node = dereference_qnode(succ);
  succ_node->tail_.store(kK42TlsNull, std::memory_order_release);
}
