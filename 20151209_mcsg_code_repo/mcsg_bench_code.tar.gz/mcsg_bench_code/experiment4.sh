for users in 1 2 4 10 15 30 60 90 120 150 180 210 239
do
  for pi_cycles in 0 100 400 1600 6400 25600 102400 409600
  do
    for rep in 0 1 2
    do
      echo "pi_cycles=$pi_cycles, users=$users, rep=$rep/3..."
      ./mcsg_bench -lock mcsg++ -guests 1 -workers $users -worker_delay=0 -guest_delay=0 -mcsgpp_pi_cycle=$pi_cycles &> "20150825-dh/exp4.$users.$pi_cycles.$rep"
    done
  done
done
