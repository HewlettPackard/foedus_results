/*
 * Copyright (c) 2014-2015, Hewlett-Packard Development Company, LP.
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details. You should have received a copy of the GNU General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * HP designates this particular file as subject to the "Classpath" exception
 * as provided by HP in the LICENSE.txt file that accompanied this code.
 */
#ifndef MCSG_HPP_
#define MCSG_HPP_

#include <numa.h>
#include <stdint.h>

#include <atomic>
#include <cassert>
#include <cstring>
#include <memory>

#include "lock_api.hpp"
#include "mcs.hpp"
#include "util.hpp"

/**
 * All special values in MCSg, like kPiMcsNodeInt, must come with kPiSocket.
 * socket==kPiSocket iff the node represents a special value.
 */
constexpr uint16_t kPiSocket = 0xFFFEU;
constexpr uint16_t kPiThread = 0xFFFEU;

const McsNodeInt kPiMcsNodeInt = McsNodeUnion(kPiSocket, kPiThread).word;
const McsNodeInt kPiSocketMask = McsNodeUnion(kPiSocket, 0).word;

/**
 * MCS-lock that allows guest (a user without any context).
 * Guest uses a special value "pi" and CAS.
 */
struct Mcsg : public McsBase {
  /**
   * Must have a constructor without arguments.
   */
  Mcsg() {}
  /** We recommend disabling copy constructor to prevent misuse */
  Mcsg(const Mcsg& other) = delete;

  /** @returns a unique name that describes the lock algorithm */
  static std::string name() { return "mcsg"; }

  /**
   * Do whatever initialization required to run the experiment.
   * @return will be the return value of main() unless it's 0 (no error).
   */
  int init(
    uint16_t socket_count,
    uint16_t in_socket_worker_count,
    uint32_t total_worker_count) {
    return init_base(socket_count, in_socket_worker_count, total_worker_count);
  }

  /**
   * Do whatever un-initialization after the experiment.
   * @return will be the return value of main() unless it's 0 (no error).
   */
  int uninit() {
    return uninit_base();
  }

  /**
   * Unconditional lock-acquire on lock_index for regular user with the given indexes.
   */
  void regular_acquire(
    uint16_t socket_index,
    uint16_t in_socket_worker_index) __attribute__((always_inline));

  /**
   * Lock-release for regular user.
   */
  void regular_release(
    uint16_t socket_index,
    uint16_t in_socket_worker_index) __attribute__((always_inline));

  /**
   * Unconditional lock-acquire on lock_index for guest user with the given fingerprint
   * (which semi-identifies the guest thread. it might not be unique).
   */
  void guest_acquire(
    uint32_t guest_fingerprint) __attribute__((always_inline));

  /**
   * Lock-release for guest user.
   */
  void guest_release(
    uint32_t guest_fingerprint) __attribute__((always_inline));

  /** Print out whatever statistics collected during the experiment. */
  void print_stat() {
  }

  void pi_spin() __attribute__((noinline));
};

inline void Mcsg::regular_acquire(
  uint16_t socket_index,
  uint16_t in_socket_worker_index) {
  std::atomic< McsNodeInt >* me = &qnodes_[socket_index][in_socket_worker_index].node_;
  auto* me_status = &statuses_[socket_index][in_socket_worker_index];
  // assert(!me_status->is_waiting());

  // me_status->set_waiting(std::memory_order_release);
  me->store(kNullMcsNodeInt, std::memory_order_release);
  const McsNodeInt myself = McsNodeUnion(socket_index, in_socket_worker_index).word;
  McsNodeInt my_group_tail = myself;
  McsNodeInt prev_tail = kNullMcsNodeInt;
  while (true) {
    // if it's obviously locked by a guest, we should wait until it's released.
    // In MCS-g, this is simply a busy-wait.
    //if (UNLIKELY(tail_.load(std::memory_order_relaxed) == kPiMcsNodeInt)) {
    //  pi_spin();
      //poll_bo_while([this]{ return tail_.load(std::memory_order_acquire) == kPiMcsNodeInt; });
    //}

    assert(my_group_tail != kPiMcsNodeInt);
    assert(my_group_tail != kNullMcsNodeInt);
    prev_tail = tail_.exchange(my_group_tail);
    if (prev_tail == kNullMcsNodeInt) {
      // me_status->set_running(std::memory_order_release);
      assert(tail_.load() != kNullMcsNodeInt);
      return;
    } else if (prev_tail == kPiMcsNodeInt) {
      my_group_tail = tail_.exchange(kPiMcsNodeInt);
      assert(my_group_tail != kPiMcsNodeInt);
      assert(my_group_tail != kNullMcsNodeInt);
      continue;
    } else {
      break;
    }
  }

  assert(prev_tail != myself);
  assert(prev_tail != my_group_tail);
  assert(prev_tail != kPiMcsNodeInt);
  assert(prev_tail != kNullMcsNodeInt);
  // assert(me_status->is_waiting());

  // NOTE: we can't have assertions like below here.
  // assert(tail_.load() != kPiMcsNodeInt);
  // assert(tail_.load() != kNullMcsNodeInt);
  // Suppose T1, T2, Guest.
  //   1. Guest acquires. null -> \pi (CAS)
  //   2. T1 observes \pi. \pi -> 1 (XCHG)
  //   3. T2 observes 1. 1 -> 2 (XCHG), it will append itself as a successor to T1.
  //   4. T1 returns \pi. 2 -> \pi (XCHG), now T1's my_group_tail is 2.
  //   5. Guest releases. \pi -> null (CAS)
  //   6. T2 comes to here. tail_.load() returns null, but I'm a waiter.. wtf (answer: it's valid!)
  //   (7). T1 re-install my_group_tail. null -> 2 (XCHG). Having received null, T1 acquired lock.
  // I wasted an hour wondering why I hit this assertion..

  McsNodeUnion prev_union;
  prev_union.word = prev_tail;
  const uint16_t pred_socket = prev_union.component.socket_;
  const uint16_t pred_thread = prev_union.component.thread_;
  assert(pred_socket < socket_count_);
  assert(pred_thread < in_socket_worker_count_);
  assert(pred_socket != socket_index || pred_thread != in_socket_worker_index);
  std::atomic< McsNodeInt >* predecessor = &qnodes_[pred_socket][pred_thread].node_;
  assert(predecessor->load() == kNullMcsNodeInt);
  me_status->set_waiting(std::memory_order_release);
  predecessor->store(myself, std::memory_order_release);

  me_status->spin_while_waiting();
  assert(!me_status->is_waiting());
}

inline void Mcsg::regular_release(
  uint16_t socket_index,
  uint16_t in_socket_worker_index) {
  std::atomic< McsNodeInt >* me = &qnodes_[socket_index][in_socket_worker_index].node_;
  assert(!statuses_[socket_index][in_socket_worker_index].is_waiting());
  const McsNodeInt myself = McsNodeUnion(socket_index, in_socket_worker_index).word;

  McsNodeInt my_node = me->load(std::memory_order_acquire);
  assert(my_node != kPiMcsNodeInt);
  assert(my_node != myself);
  if (my_node == kNullMcsNodeInt) {
    McsNodeInt expected = myself;
    if (LIKELY(tail_.compare_exchange_strong(expected, kNullMcsNodeInt))) {
      return;
    }

    assert(expected != kNullMcsNodeInt);
    assert(expected != myself);
    assert(expected != kPiMcsNodeInt);  // in MCS-g, guest has no predecessor

    assert(tail_.load() != myself);
    spin_while([me]{ return me->load(std::memory_order_acquire) == kNullMcsNodeInt; });
    my_node = me->load(std::memory_order_acquire);
  }

  assert(my_node != kPiMcsNodeInt);
  assert(my_node != myself);
  assert(my_node != kNullMcsNodeInt);

  assert(!statuses_[socket_index][in_socket_worker_index].is_waiting());

  McsNodeUnion my_node_union;
  my_node_union.word = my_node;
  const uint16_t socket = my_node_union.component.socket_;
  const uint16_t thread = my_node_union.component.thread_;
  assert(socket < socket_count_);
  assert(thread < in_socket_worker_count_);
  assert(socket != socket_index || thread != in_socket_worker_index);
  auto* successor_status = &statuses_[socket][thread];
  assert(successor_status->is_waiting());
  successor_status->set_running(std::memory_order_release);
}

inline void Mcsg::guest_acquire(uint32_t /*guest_fingerprint*/) {
  poll_bo_while([this]{
    McsNodeInt old_int = kNullMcsNodeInt;
    return !tail_.compare_exchange_weak(old_int, kPiMcsNodeInt);
  }, 256);
  assert(tail_.load() != kNullMcsNodeInt);
}

inline void Mcsg::guest_release(uint32_t /*guest_fingerprint*/) {
  spin_while([this]{
    McsNodeInt old_int = kPiMcsNodeInt;
    return !tail_.compare_exchange_weak(old_int, kNullMcsNodeInt);
  });
}

#endif  // MCSG_HPP_
