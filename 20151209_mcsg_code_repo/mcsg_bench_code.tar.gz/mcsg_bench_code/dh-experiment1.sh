dir="`date +%F`-dh"
mkdir -p $dir
for b in "compact" #"compact" #"sparse"
do
  for w in 0 #1000 #0
  do
    for algo in mcsg++ mcsg #mcs mcsg tatas clh k42 c_mcsg_mcs #mcsb mcsg+
    do
      for users in 240 #120 150 180 1 2 4 8 15 30 45 60 90 210 240
      do
        for pi in 100 #-1
        do
          for tkt in -1 #100 #-1
          do
            for rep in 0 1 2 3 4
            do
              echo "pi cycle=$pi, tkt cycle=$tkt, wait=$w us, bind=$b, algo=$algo, workers=$users, rep=$rep..."
              ./mcsg_bench -lock $algo -guests 0 -workers $users -worker_delay=$w -guest_delay=$w -mcsgpp_pi_cycle=$pi -mcsgpp_tkt_cycle=$tkt -core_bind=$b -duration=10 &> "$dir/exp1.wc-$w.pc-$pi.tc-$tkt.bind-$b.$algo.$users.$rep"
            done
          done
        done
      done
    done
  done
done
