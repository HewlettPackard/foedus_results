#!/bin/bash
# Experiment 2: regular user throughput/guest stdev_ns when there is one guest
# x: number of regular users
# y: throughput of regular users
mkdir -p csv
mkdir -p eps
trap "rm exp2-tmp -fr" EXIT

############ Worker throughput with stdev ###############
export gp_csv="csv/exp2-worker-throughput-hi-contention-stdev.csv"
./summarize-exp2-stdev.sh data/exp3.wc-0.pc-100.tc-100.bind-compact worker iter 5 > $gp_csv
gnuplot ./plt/exp2-worker-throughput-hi-contention-stdev.plt

############ Guest latency #############
export gp_csv="csv/exp2-guest-ave_ns-hi-contention.csv"
./summarize-exp2-stdev.sh data/exp3.wc-0.pc-100.tc-100.bind-compact guest ave_ns 5 > $gp_csv
gnuplot ./plt/exp2-guest-ave_ns-hi-contention.plt

