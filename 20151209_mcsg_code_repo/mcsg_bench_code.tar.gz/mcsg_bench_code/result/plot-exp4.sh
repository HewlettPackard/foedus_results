#!/bin/bash
# x: number of regular users
# y: throughput
# For throughput, C-MCSg-MCS is not plotted by default. Turn it on in the last line of exp1-throughput.plt.
# For stdev_ns, TATAS is not plotted by default. Turn it on in the last lines of exp1-stdev-ns.plt.
mkdir -p csv
mkdir -p eps

export gp_csv="csv/exp4-inversion-hi-contention.csv"
./summarize-exp4.sh > $gp_csv
gnuplot ./plt/exp4-inversion-hi-contention.plt
