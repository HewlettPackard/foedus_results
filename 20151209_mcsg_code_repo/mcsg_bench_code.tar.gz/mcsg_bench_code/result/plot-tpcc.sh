#!/bin/bash
# Experiment 3
# x: number of guests
# y: worker throughput/worker stdev_ns/guest stdev_ns
# Total number of thread always= 240
# For stdev plots TATAS is not included. Enable it in the .plt files.
mkdir -p csv
mkdir -p eps

export gp_csv="csv/tpcc.csv"
./summarize-tpcc.sh data > $gp_csv
gnuplot ./plt/tpcc.plt
