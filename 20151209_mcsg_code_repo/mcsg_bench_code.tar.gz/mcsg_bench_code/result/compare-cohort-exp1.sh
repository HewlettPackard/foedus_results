#!/bin/bash
# $1 - data file location
# $2 - iter (for throughput) or ave_ns (for avg latency) or stdev_ns

if [ "$#" -lt 2 ]; then
  echo -ne "Usage: \n \
    compare.sh [data location] [iter/ave_ns/stdev_ns]\n"
  exit
fi

exp=$1/exp1.wc-0.pc-100.tc-100.bind-compact1
#exp=$1/exp1.wc-0.pc-100.tc-100.bind-compact
keyword=$2

# A helper function that does the dirty work
function extract_result()
{
  if [ "$lock" == "mcsg++" ]; then
    echo -ne `tail -2 $file | head -1 | cut -d ',' -f1 | sed -e 's/.*<'$keyword'>//' -e 's/<.*//'`
  else
    echo -ne `tail -1 $file | cut -d ',' -f1 | sed -e 's/.*<'$keyword'>//' -e 's/<.*//'`
  fi
}

echo -ne "threads"


for lock in mcs mcsg mcsg++ c_mcsg_mcs  #tatas k42 clh mcs mcsg mcsg++ mcsb c_mcsg_mcs
do
  if [ `ls $exp.$lock.* 2> /dev/null | wc -l` -gt 0 ]; then
    echo -ne ",$lock"
  fi
done

echo

reps=5

for thread in 1 2 4 10 15 30 60 90 120 150 180 210 224 240
do
  if [ `ls $exp.*.$thread.* 2> /dev/null | wc -l` -gt 0 ]; then
    echo -ne $thread
    for lock in mcs mcsg mcsg++ c_mcsg_mcs #tatas k42 clh mcs mcsg mcsg++ mcsb c_mcsg_mcs
    do
      if [ `ls $exp.$lock.$thread.* 2> /dev/null | wc -l` -gt 0 ]; then
        total_val=0
        i=0
        while [ $i -lt $reps ]; do
          file=$exp.$lock.$thread.$i
          ((i++))
          val=$(extract_result)
          total_val=`echo "$total_val + $val" | bc`
        done
        echo -ne ","
        echo -ne `echo "scale=2; $total_val / $reps" | bc -l`
      fi
    done
  echo
  fi
done

