#!/bin/bash
# $1 - experiment file location/name, e.g., data/exp1

# For global properties:
# $2 - keyword (experiment_elapsed, total_throughput, and wrapup_elapsed)
# $3 - number of repetitions to consider, usually max 3

# For worker/guest stats:
# $2 - worker or guest
# $3 - iter (for throughput) or ave_ns (for avg latency) or stdev_ns
# $4 - number of repetitions to consider, usually max 3

if [ "$#" -lt 2 ] || [ "$#" -gt 4 ]; then
  echo -ne "Usage: \n \
    summarize.sh [exp] [worker/guest] [iter/ave_ns/stdev_ns]\n \
    summarize.sh [exp] [total_throughput/experiment_elapsed/wrapup_elapsed]\n"
  exit
fi

exp=$1
user=$2
keyword=""

if [ "$user" == "worker" ] || [ "$user" == "guest" ]; then
  keyword=$3
  if [ "$keyword" != "iter" ] && \
     [ "$keyword" != "ave_ns" ] && \
     [ "$keyword" != "stdev_ns" ]; then
    echo "Wrong argument: $user $keyword"
    exit
  fi
else
  keyword=$2
  user=$2  # make extract_result's life easier...
  if [ "$keyword" != "total_throughput" ] && \
     [ "$keyword" != "wrapup_elapsed" ] && \
     [ "$keyword" != "experiment_elapsed" ]; then
    echo "Wrong argument: $keyword"
    exit
  fi
fi

# A helper function that does the dirty work
function extract_result()
{
  line=`tail -1 $file`
  if [ "$lock" == "mcsg++" ]; then
    line=`tail -2 $file | head -1`
  fi
  if [ "$user" == "worker" ]; then
    echo -ne `echo $line | cut -d ',' -f1 | sed -e 's/.*<'$keyword'>//' -e 's/<.*//'`
  elif [ "$user" == "guest" ]; then
    if [[ "$keyword" == "ave_ns" && "$lock" == "mcs" ]]; then
      echo -ne `echo $line | cut -d ',' -f1 | sed -e 's/.*<'$keyword'>//' -e 's/<.*//'`
    elif [[ "$keyword" == "ave_ns" && "$lock" == "clh" ]]; then
      echo -ne `echo $line | cut -d ',' -f1 | sed -e 's/.*<'$keyword'>//' -e 's/<.*//'`
    else
      echo -ne `echo $line | cut -d ',' -f2 | sed -e 's/.*<'$keyword'>//' -e 's/<.*//'`
    fi
  elif [ "$user" == "total_throughput" ]; then
    echo -ne `echo $line | cut -d ',' -f3 | sed -e 's/.*'$keyword'=//' -e 's/,.*//'`
  elif [ "$user" == "experiment_elapsed" ]; then
    echo -ne `echo $line | cut -d ',' -f4 | sed -e 's/.*'$keyword'=//' -e 's/sec.*//'`
  elif [ "$user" == "wrapup_elapsed" ]; then
    echo -ne `echo $line | cut -d ',' -f5 | sed -e 's/.*'$keyword'=//' -e 's/sec.*//'`
  fi
}

reps=3
if [ "$user" == "worker" ] || [ "$user" == "guest" ]; then
  if [ "$#" -eq 4 ]; then
    reps="$4"
  fi
else
  if [ "$#" -eq 3 ]; then
    reps="$3"
  fi
fi

echo "lock,mean,stdev,color"

######## right now only supports guest-ave_ns and worker-iter. No other combinations. #######
if [ $keyword == "ave_ns" ]; then
  dd=1000000
else
  dd=10000000   # iter
fi

c=0
for lock in tatas k42 k42tls clh clhtls mcs mcsg mcsg++ #mcsg+ #c_mcsg_mcs mcsg+
do
  # one guest
    declare -a MIN
    declare -a MAX
    declare -a T
    total_val=0
    i=0
    min=0
    max=0
    ((c++))
    if [ "$lock" == "tatas" ]; then
      echo -ne "TATAS,"
    elif [ "$lock" == "k42" ]; then
      echo -ne "K42,"
    elif [ "$lock" == "k42tls" ]; then
      echo -ne "K42-TLS,"
    elif [ "$lock" == "clh" ]; then
      echo -ne "CLH,"
    elif [ "$lock" == "clhtls" ]; then
      echo -ne "CLH-TLS,"
    elif [ "$lock" == "mcs" ]; then
      echo -ne "MCS,"
    elif [ "$lock" == "mcsg" ]; then
      echo -ne "MCSg,"
    elif [ "$lock" == "mcsg++" ]; then
      echo -ne "MCSg++,"
    elif [ "$lock" == "mcsg+" ]; then
      echo -ne "MCSg+,"
    fi
    while [ $i -lt $reps ]; do
      if [[ "$lock" == "mcs" || "$lock" == "clh" ]]; then
        file=data/exp1.wc-0.pc-100.tc-100.bind-compact1.$lock.224.$i
      else
        file=$exp.$lock.1.$i
      fi
      val=$(extract_result)
      larger=`echo $val '>' $max | bc -l`
      if [ $larger -eq 1 ]; then
        max=$val
      fi
      smaller=`echo $val '<' $min | bc -l`
      if [ $smaller -eq 1 ]; then
        min=$val
      else
        is_zero=`echo $min '==' 0 | bc -l`
        if [ $is_zero -eq 1 ]; then
          min=$val
        fi
      fi
      T[i]=`echo "$val / $dd" | bc -l`
      total_val=`echo "$total_val + $val" | bc`
      ((i++))
    done
    if [ "$keyword" == "total_throughput" ] || \
       [ "$user" == "guest" ] || \
       [ "$user" == "worker" ]; then
      v=`echo "scale=4; $total_val / $reps / $dd" | bc -l`
      # Round it up/down to three decimal digits
      v=`echo "scale=3; ($v + 0.0005) / 1" | bc -l`
      v=`echo "if ($v < 1) print 0; $v" | bc`
      echo -ne "$v"
    fi
    mean=`echo "$total_val / $reps / $dd" | bc -l`
    mean=`echo "if ($mean < 1) print 0; $mean" | bc`
    stdev=$(echo "${T[*]}" | awk -vM=$mean '{for(j=1;j<=NF;j++){sum+=($j-M)*($j-M)};print sqrt(sum/(NF-1))}')
    echo -ne ",$stdev,$c\n"
done
