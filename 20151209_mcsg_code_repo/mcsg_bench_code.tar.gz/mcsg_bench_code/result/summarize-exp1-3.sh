#!/bin/bash
# $1 - experiment file location/name, e.g., data/exp1

# For global properties:
# $2 - keyword (experiment_elapsed, total_throughput, and wrapup_elapsed)
# $3 - number of repetitions to consider, usually max 3

# For worker/guest stats:
# $2 - worker or guest
# $3 - iter (for throughput) or ave_ns (for avg latency) or stdev_ns
# $4 - number of repetitions to consider, usually max 3

if [ "$#" -lt 2 ] || [ "$#" -gt 4 ]; then
  echo -ne "Usage: \n \
    summarize.sh [exp] [worker/guest] [iter/ave_ns/stdev_ns]\n \
    summarize.sh [exp] [total_throughput/experiment_elapsed/wrapup_elapsed]\n"
  exit
fi

exp=$1
user=$2
keyword=""

if [ "$user" == "worker" ] || [ "$user" == "guest" ]; then
  keyword=$3
  if [ "$keyword" != "iter" ] && \
     [ "$keyword" != "ave_ns" ] && \
     [ "$keyword" != "stdev_ns" ]; then
    echo "Wrong argument: $user $keyword"
    exit
  fi
else
  keyword=$2
  user=$2  # make extract_result's life easier...
  if [ "$keyword" != "total_throughput" ] && \
     [ "$keyword" != "wrapup_elapsed" ] && \
     [ "$keyword" != "experiment_elapsed" ]; then
    echo "Wrong argument: $keyword"
    exit
  fi
fi

# A helper function that does the dirty work
function extract_result()
{
  line=`tail -1 $file`
  if [ "$lock" == "mcsg++" ]; then
    line=`tail -2 $file | head -1`
  fi
  if [ "$user" == "worker" ]; then
    echo -ne `echo $line | cut -d ',' -f1 | sed -e 's/.*<'$keyword'>//' -e 's/<.*//'`
  elif [ "$user" == "guest" ]; then
    echo -ne `echo $line | cut -d ',' -f2 | sed -e 's/.*<'$keyword'>//' -e 's/<.*//'`
  elif [ "$user" == "total_throughput" ]; then
    echo -ne `echo $line | cut -d ',' -f3 | sed -e 's/.*'$keyword'=//' -e 's/,.*//'`
  elif [ "$user" == "experiment_elapsed" ]; then
    echo -ne `echo $line | cut -d ',' -f4 | sed -e 's/.*'$keyword'=//' -e 's/sec.*//'`
  elif [ "$user" == "wrapup_elapsed" ]; then
    echo -ne `echo $line | cut -d ',' -f5 | sed -e 's/.*'$keyword'=//' -e 's/sec.*//'`
  fi
}

echo -ne "threads"

for lock in tatas k42 k42tls clh clhtls mcs mcsg mcsg++ mcsg+ #mcsb c_mcsg_mcs mcsg+
do
  if [ `ls $exp.$lock.* 2> /dev/null | wc -l` -gt 0 ]; then
    echo -ne ",$lock"
  fi
done

echo

reps=3
if [ "$user" == "worker" ] || [ "$user" == "guest" ]; then
  if [ "$#" -eq 4 ]; then
    reps="$4"
  fi
else
  if [ "$#" -eq 3 ]; then
    reps="$3"
  fi
fi

for thread in 1 2 4 8 15 30 60 90 120 150 180 210 224 #240
do
  if [ `ls $exp.*.$thread.* 2> /dev/null | wc -l` -gt 0 ]; then
    echo -ne $thread
    for lock in tatas k42 k42tls clh clhtls mcs mcsg mcsg++ mcsg+ #c_mcsg_mcs mcsg+
    do
      if [ `ls $exp.$lock.$thread.* 2> /dev/null | wc -l` -gt 0 ]; then
        total_val=0
        i=0
        while [ $i -lt $reps ]; do
          file=$exp.$lock.$thread.$i
          ((i++))
          val=$(extract_result)
          total_val=`echo "$total_val + $val" | bc`
        done
        echo -ne ","
        if [ "$keyword" == "total_throughput" ] || \
           [ "$user" == "guest" ] || \
           [ "$user" == "worker" ]; then
          echo -ne `echo "scale=2; $total_val / $reps" | bc -l`
        elif [ "$keyword" == "wrapup_elapsed" ]; then
          echo -ne `echo "scale=10; $total_val / $reps" | bc -l `
        elif [ "$keyword" == "experiment_elapsed" ]; then
          echo -ne `echo "scale=4; $total_val / $reps" | bc -l `
        fi
      fi
    done
  echo
  fi
done

