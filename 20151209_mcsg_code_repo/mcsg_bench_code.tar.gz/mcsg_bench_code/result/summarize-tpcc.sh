#!/bin/bash
if [ "$#" != 1 ]; then
  echo "Usage: summarize.sh [exp data dir]"
  exit
fi

# A helper function that does the dirty work
function extract_mtps()
{
  echo -ne `grep "final result" $file | sed -e 's/.*<MTPS>//' -e 's/<.*//'`
}

echo "lock,mean,stdev"

# Require nine samples, we then remove the highest and lowest
file_count=9
color=1

for lock in tatas mcs mcsg
do
  if [ $lock == "tatas" ]; then
    echo -ne "TATAS"
  elif [ $lock == "mcs" ]; then
    echo -ne "MCS"
  elif [ $lock == "mcsg" ]; then
    echo -ne "MCSg"
  else
    echo "Wrong lock type"
    exit
  fi
  declare -a MAX
  declare -a MIN
  declare -a MTPS

  total_val=0
  i=0
  max=0
  min=0
  lock_i=0
  while [ $i -le $file_count ]; do
    file=$1/$lock/result_tpcc_dh.n0.r$i.log
    if [ `grep final $file | wc -l` -gt 0 ]; then
      val=$(extract_mtps)
      larger=`echo $val '>' $max | bc -l`
      if [ $larger -eq 1 ]; then
        max=$val
      fi
      smaller=`echo $val '<' $min | bc -l`
      if [ $smaller -eq 1 ]; then
        min=$val
      else
        is_zero=`echo $min '==' 0 | bc -l`
        if [ $is_zero -eq 1 ]; then
          min=$val
        fi
      fi
      MTPS[i]=$val
      total_val=`echo "$total_val + $val" | bc -l`
    fi
    ((i++))
  done

  if [ $i -ne $((file_count+1)) ]; then
    echo "Not enough data"
    exit
  fi

  MAX[$lock_i]=$max
  MIN[$lock_i]=$min
  sample_count=$((file_count-2))

  # Exclude the highest and lowest
  total_val=`echo "$total_val - ${MAX[$lock_i]} - ${MIN[$lock_i]}" | bc -l`
  ((lock_i++))
  mean=`echo "$total_val / $sample_count" | bc -l`
  mean=`echo "if ($mean < 1) print 0; $mean" | bc`

  did_min=0
  did_max=0
  i=0

  # Remove highest and lowest; don't do this in the same loop in case
  # we got the same highest and lowest (tho highly unlikely)
  for m in ${MTPS[*]}; do
    if [ $did_min -eq 0 ]; then
      equal=`echo "$m == $min" | bc -l`
      if [ $equal -eq 1 ]; then
        did_min=1
        unset MTPS[i]
      fi
    fi
    ((i++))
  done

  i=0
  for m in ${MTPS[*]}; do
    if [ $did_max -eq 0 ]; then
      equal=`echo "$m == $max" | bc -l`
      if [ $equal -eq 1 ]; then
        did_max=1
        unset MTPS[i]
      fi
    fi
    ((i++))
  done

  stdev=$(echo "${MTPS[*]}" | awk -vM=$mean '{for(j=1;j<=NF;j++){sum+=($j-M)*($j-M)};print sqrt(sum/(NF-1))}')
  echo -ne ",$mean,$stdev,$color\n"
  ((color++))
done

