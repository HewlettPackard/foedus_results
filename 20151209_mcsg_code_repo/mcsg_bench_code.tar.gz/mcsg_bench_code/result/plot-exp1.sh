#!/bin/bash
# x: number of regular users
# y: throughput
# For throughput, C-MCSg-MCS is not plotted by default. Turn it on in the last line of exp1-throughput.plt.
# For stdev_ns, TATAS is not plotted by default. Turn it on in the last lines of exp1-stdev-ns.plt.
mkdir -p csv
mkdir -p eps

# high contention
export gp_csv="csv/exp1-throughput.csv"
./summarize-exp1-3.sh data/exp1.wc-0.pc-100.tc-100.bind-compact1 worker iter 5 > $gp_csv

# Get up to 60 threads 
#head -7 gp_tmp > $gp_csv
#./summarize-exp1-3.sh data/exp1.wc-0.pc-100.tc-100.bind-sparse worker iter 5 > $gp_csv

gnuplot ./plt/exp1-throughput-hi-contention.plt
exit
# low contention (with 1us wait)
export gp_csv="csv/exp1-throughput.csv"
./summarize-exp1-3.sh data/exp1.wc-1000.pc-100.tc-100.bind-compact worker iter 5 > $gp_csv
gnuplot ./plt/exp1-throughput-lo-contention.plt

#export gp_csv="csv/exp1-stdev-ns.csv"
#./summarize-exp1-3.sh data/exp1 worker stdev_ns > $gp_csv
#gnuplot ./plt/exp1-stdev-ns.plt
