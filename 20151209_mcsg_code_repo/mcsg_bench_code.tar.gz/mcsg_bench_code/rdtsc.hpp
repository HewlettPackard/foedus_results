/*
 * Copyright (c) 2014-2015, Hewlett-Packard Development Company, LP.
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details. You should have received a copy of the GNU General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * HP designates this particular file as subject to the "Classpath" exception
 * as provided by HP in the LICENSE.txt file that accompanied this code.
 */
#ifndef RDTSC_HPP_
#define RDTSC_HPP_
/**
 * @file rdtsc.hpp
 * @brief Implements an RDTSC (Real-time time stamp counter) wait to emulate latency on slower
 * devices.
 */

#include <stdint.h>

#include <chrono>

/**
 * @brief Returns the current CPU cycle via x86 RDTSC.
 */
inline uint64_t get_rdtsc() {
  uint32_t low, high;
  asm volatile("rdtsc" : "=a" (low), "=d" (high));
  return (static_cast<uint64_t>(high) << 32) | low;
}

/**
 * @brief Wait until the given CPU cycles elapse.
 * @param[in] cycles CPU cycles to wait for
 * @details
 * In case of context switch to a different CPU that has a very different timing (esp on NUMA),
 * we also check if the RDTSC value is not bogus. In that case, we exit the wait.
 * This is also a safety net for wrap-around.
 * Anyways, it's a rare case.
 */
inline void wait_rdtsc_cycles(uint64_t cycles) {
  uint64_t cycle_error = get_rdtsc() - cycles;
  uint64_t cycle_until = get_rdtsc() + cycles;
  while (true) {
    uint64_t current = get_rdtsc();
    if (current >= cycle_until || current <= cycle_error) {
      break;
    }
  }
}

/**
 * @return estimated cycles per second
 */
inline double calibrate_rdtsc_cycles_per_second() {
  // First, let's make this core really busy for 10 seconds so that turbo-mode etc is triggered.
  // we don't know the rate at this point, but 2GHz shouldn't be too off nowadays.
  constexpr uint64_t kRoughCyclesPerSecond = 2ULL << 30;
  constexpr uint64_t kSecondsToBurn = 10;
  constexpr uint64_t kCyclesToBurn = kRoughCyclesPerSecond * kSecondsToBurn;
  wait_rdtsc_cycles(kCyclesToBurn);

  // Then another 5 seconds to calibrate
  constexpr uint64_t kSecondsToCalibrate = 5;
  constexpr uint64_t kCyclesToCalibrate = kRoughCyclesPerSecond * kSecondsToCalibrate;
  auto started = std::chrono::high_resolution_clock::now();
  wait_rdtsc_cycles(kCyclesToCalibrate);
  auto ended = std::chrono::high_resolution_clock::now();
  std::chrono::duration<double> elapsed_seconds = ended - started;
  return kCyclesToCalibrate / elapsed_seconds.count();
}

#endif  // RDTSC_HPP_
