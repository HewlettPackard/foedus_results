for algo in clh clhtls mcsb mcsg mcs mcsg++ tatas k42 k42tls
do
  echo "algo=$algo guests=0"
  ./mcsg_bench -duration=2 -lock $algo -guests 0 -workers 4 -worker_delay=0
done

for algo in mcsb mcsg mcsg++ tatas k42 k42tls clhtls
do
  echo "algo=$algo guests=1"
  ./mcsg_bench -duration=2 -lock $algo -guests 1 -workers 4 -worker_delay=0 -guest_delay=0
done
