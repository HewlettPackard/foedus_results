/*
 * Copyright (c) 2014-2015, Hewlett-Packard Development Company, LP.
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details. You should have received a copy of the GNU General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * HP designates this particular file as subject to the "Classpath" exception
 * as provided by HP in the LICENSE.txt file that accompanied this code.
 */
#ifndef CLH_HPP_
#define CLH_HPP_

#include <numa.h>

#include <atomic>
#include <cassert>
#include <cstring>
#include <memory>

#include "lock_api.hpp"

typedef uint64_t ClhNodeInt;  // used as std::atomic containee
constexpr uint64_t kClhNullNodeInt = -1;
constexpr uint16_t kClhNullSocket = 0xFFFFU;
constexpr uint16_t kClhNullThread = 0xFFFFU;

struct ClhNode {
  uint16_t pred_socket_;
  uint16_t pred_thread_;
  std::atomic< bool > succ_must_wait_;
  char filler_[256 - sizeof(succ_must_wait_)];

  ClhNode() : pred_socket_(kClhNullSocket), pred_thread_(kClhNullThread) {
    succ_must_wait_.store(false);
  }
};

/**
 * Implements the CLH lock.
 */
struct Clh {
  /** @returns a unique name that describes the lock algorithm */
  static std::string name() { return "clh"; }

  /**
   * Must have a constructor without arguments.
   */
  Clh() {
    socket_count_ = 0;
    in_socket_worker_count_ = 0;
    tail_.store(kClhNullNodeInt);
    qnodes_array_auto_release_.reset(nullptr);
    qnodes_ = nullptr;
  }

  /** We recommend disabling copy constructor to prevent misuse */
  Clh(const Clh& other) = delete;

  /**
   * Do whatever initialization required to run the experiment.
   * @return will be the return value of main() unless it's 0 (no error).
   */
  int init(
    uint16_t socket_count,
    uint16_t in_socket_worker_count,
    uint32_t total_worker_count) {
    socket_count_ = socket_count;
    in_socket_worker_count_ = in_socket_worker_count;
    tail_.store(kClhNullNodeInt);
    qnodes_array_auto_release_.reset(new ClhNode*[socket_count]);
    qnodes_ = qnodes_array_auto_release_.get();
    uint32_t per_socket_qnodes = in_socket_worker_count + 1;
    for (auto socket = 0; socket < socket_count; ++socket) {
      qnodes_[socket] = reinterpret_cast<ClhNode*>(
        ::numa_alloc_onnode(sizeof(ClhNode) * per_socket_qnodes, socket));
      // One extra node each socket
      std::memset(qnodes_[socket], 0, sizeof(ClhNode) * per_socket_qnodes);
      for (auto thread_index = 0; thread_index <= in_socket_worker_count; ++thread_index) {
        qnodes_[socket][thread_index].succ_must_wait_.store(false);
      }
    }

    qnode_ints_array_auto_release_.reset(new ClhNodeInt*[socket_count]);
    qnode_ints_ = qnode_ints_array_auto_release_.get();
    for (auto socket = 0; socket < socket_count; ++socket) {
      qnode_ints_[socket] = reinterpret_cast<ClhNodeInt*>(
        ::numa_alloc_onnode(sizeof(ClhNodeInt) * per_socket_qnodes, socket));
      // One extra node each socket
      for (auto thread_index = 0; thread_index < per_socket_qnodes; ++thread_index) {
        qnode_ints_[socket][thread_index] = (static_cast<uint32_t>(socket) << 16) | thread_index;
      }
    }
    return 0;
  }

  /**
   * Do whatever un-initialization after the experiment.
   * @return will be the return value of main() unless it's 0 (no error).
   */
  int uninit() {
    if (qnodes_) {
      for (auto socket = 0; socket < socket_count_; ++socket) {
        if (qnodes_[socket]) {
          ::numa_free(qnodes_[socket], sizeof(ClhNode) * (in_socket_worker_count_ + 1));
          qnodes_[socket] = nullptr;
        }
      }
      qnodes_array_auto_release_.reset(nullptr);
      qnodes_ = nullptr;
    }
    if (qnode_ints_) {
      for (auto socket = 0; socket < socket_count_; ++socket) {
        if (qnode_ints_[socket]) {
          ::numa_free(qnode_ints_[socket], sizeof(ClhNodeInt) * in_socket_worker_count_);
          qnode_ints_[socket] = nullptr;
        }
      }
      qnode_ints_array_auto_release_.reset(nullptr);
      qnode_ints_ = nullptr;
    }
    return 0;
  }

  /**
   * Unconditional lock-acquire for regular user with the given indexes.
   */
  void regular_acquire(
    uint16_t socket_index,
    uint16_t in_socket_worker_index) __attribute__((always_inline));

  /**
   * Lock-release for regular user.
   */
  void regular_release(
    uint16_t socket_index,
    uint16_t in_socket_worker_index) __attribute__((always_inline));

  /**
   * Unconditional lock-acquire for guest user with the given fingerprint
   * (which semi-identifies the guest thread. it might not be unique).
   */
  void guest_acquire(
    uint32_t guest_fingerprint) __attribute__((always_inline));

  /**
   * Lock-release for guest user.
   */
  void guest_release(
    uint32_t guest_fingerprint) __attribute__((always_inline));

  /** Print out whatever statistics collected during the experiment. */
  void print_stat();

  /// Remember what init() set
  uint16_t socket_count_;
  uint16_t in_socket_worker_count_;
  std::atomic< ClhNodeInt > tail_;

  /**
   * qnodes[socket][thread] is the QNode of the specified thread.
   * qnodes[socket] is an array allocated in the socket using libnuma.
   * As noted below, each thread inherits its predecessor's QNode upon
   * lock release; the socket and thread indexes might be different
   * from the calling thread's real topology location.
   */
  ClhNode** qnodes_;
  std::unique_ptr< ClhNode*[] > qnodes_array_auto_release_;

  /**
   * qnode_ints_[socket][thread] tells the thread which QNode to grab
   * in qnodes_ array. Since a predecessor has no idea when the successor
   * will really grab the lock after it sets succ_must_wait to false, it
   * has to assume the worst. So the predecessor will set
   * qnode_ints_[socket][thread] to its predecessor's ClhNodeInt and use
   * that QNode next time.
   */
  ClhNodeInt** qnode_ints_;
  std::unique_ptr< ClhNodeInt*[] > qnode_ints_array_auto_release_;
};

inline void Clh::regular_acquire(
  uint16_t socket_index,
  uint16_t in_socket_worker_index) {
  // Figure out which QNode to use
  ClhNodeInt qint = qnode_ints_[socket_index][in_socket_worker_index];
  auto socket = qint >> 16;
  auto thread = qint & 0xFF;
  ClhNode* me = &qnodes_[socket][thread];  // the real QNode to use
  assert(me->succ_must_wait_.load() == false);
  me->succ_must_wait_.store(true, std::memory_order_release);

  // tail_ stores the *real* QNode's location, not the acquiring thread's,
  // so that I can find the successor can find the right QNode to spin on
  ClhNodeInt pred_int = tail_.exchange(static_cast<uint32_t>(socket) << 16 | thread);
  uint16_t pred_socket = pred_int >> 16;
  uint16_t pred_thread = pred_int & 0xFFFF;

  // Mark down the predecessor's QNode location for use in release
  if (pred_socket != kClhNullSocket) {
    assert(pred_thread != kClhNullThread);
    me->pred_socket_ = pred_socket;
    me->pred_thread_ = pred_thread;
    ClhNode* pred = &qnodes_[pred_socket][pred_thread];
    while (pred->succ_must_wait_.load(std::memory_order_acquire)) {}
  } else {
    // The very first to grab this lock, use the extra node
    assert(pred_thread == kClhNullThread);
    me->pred_socket_ = socket_index;
    me->pred_thread_ = in_socket_worker_count_;
  }
  assert(tail_.load() != kClhNullNodeInt);
}

inline void Clh::regular_release(
  uint16_t socket_index,
  uint16_t in_socket_worker_index) {
  // Go back to my current QNode to find out which QNode to inherit
  ClhNodeInt qint = qnode_ints_[socket_index][in_socket_worker_index];
  auto socket = qint >> 16;
  auto thread = qint & 0xFF;
  ClhNode* me = &qnodes_[socket][thread];
  assert(me->succ_must_wait_.load() == true);

  // The next round of acquire will use this new QNode inherited from
  // my predecessor
  qnode_ints_[socket_index][in_socket_worker_index] =
    (static_cast<uint32_t>(me->pred_socket_) << 16) | me->pred_thread_;
  me->succ_must_wait_.store(false, std::memory_order_release);
}

inline void Clh::guest_acquire(uint32_t /*guest_fingerprint*/) {
  std::cerr << "CLH doesn't support guest-lock" << std::endl;
  std::exit(1);
}

inline void Clh::guest_release(uint32_t /*guest_fingerprint*/) {
  std::cerr << "CLH doesn't support guest-lock" << std::endl;
  std::exit(1);
}
#endif  // CLH_HPP_
