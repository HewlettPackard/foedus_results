/*
 * Copyright (c) 2014-2015, Hewlett-Packard Development Company, LP.
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details. You should have received a copy of the GNU General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * HP designates this particular file as subject to the "Classpath" exception
 * as provided by HP in the LICENSE.txt file that accompanied this code.
 */
#include "clhtls.hpp"

struct ClhNodePool {
  enum Constant {
    /**
     * this pool so far doesn't support a dynamic expansion.
     * in our experiment we just statically allocate a fixed size array
     */
    kMaxPoolSize = 1 << 12,
  };

  ClhTlsNode pool_[kMaxPoolSize];
  std::atomic<uint32_t> borrowed_count_;

  ClhNodePool() {
    // Starts from 2 (avoid kClhTlsSentinel, kClhTlsNull)
    borrowed_count_ = 2;
  }
  ClhTlsIndex borrow()  __attribute__((always_inline));
  ClhTlsNode* deferefence(ClhTlsIndex index)  __attribute__((always_inline));
  // no support for "return" so far. our experiment doesn't need it
};

/**
 * This corresponds to "thread_qnode_ptrs[self]" in Scott's Fig 4.14.
 * We use TLS to hold "my next queue node", except that we store
 * the index, not the raw pointer.
 * @note This index changes for each lock acquisition, reusing
 * the queue node of the previous predecessor.
 * Remember, if we don't do so (keep using the same queue node),
 * it's not safe to reset succ_must_wait_ in next lock acquire.
 * Reusing predecessor's queue node is safe because _this thread_
 * is the only reader in previous round.
 */
__thread ClhTlsIndex clhtls_self_index;

/**
 * This is the instance of "shared" qnode pool.
 * Conceptually it's on shared-memory for multi-process, but in this experiment
 * it's just a global variable.
 */
ClhNodePool global_clhtls_pool;

ClhTlsIndex ClhTls::borrow_tls_qnode() {
  if (clhtls_self_index != kClhTlsNull) {
    return clhtls_self_index;
  }

  clhtls_self_index = global_clhtls_pool.borrow();
  return clhtls_self_index;
}

ClhTlsNode* ClhTls::dereference_qnode(ClhTlsIndex index) {
  assert(index != kClhTlsNull);
  assert(index < ClhNodePool::kMaxPoolSize);
  if (index == kClhTlsSentinel) {
    return &sentinel_;
  }
  return global_clhtls_pool.deferefence(index);
}

ClhTlsIndex ClhNodePool::borrow() {
  uint32_t my_index = borrowed_count_.fetch_add(1U);
  assert(my_index < kMaxPoolSize);
  assert(my_index != kClhTlsNull);
  assert(my_index != kClhTlsSentinel);
  pool_[my_index].succ_must_wait_ = false;
  return my_index;
}
ClhTlsNode* ClhNodePool::deferefence(ClhTlsIndex index)  {
  return pool_ + index;
}

void ClhTls::guest_acquire(uint32_t /*guest_fingerprint*/) {
  ClhTlsIndex self = borrow_tls_qnode();
  ClhTlsNode* p = dereference_qnode(self);
  p->succ_must_wait_.store(true, std::memory_order_release);
  ClhTlsIndex pred = tail_.exchange(self);
  assert(pred != self);

  ClhTlsNode* pred_node = dereference_qnode(pred);
  while (pred_node->succ_must_wait_.load(std::memory_order_acquire)) {
    continue;
  }

  head_.store(self, std::memory_order_release);
  clhtls_self_index = pred;
}

void ClhTls::guest_release(uint32_t /*guest_fingerprint*/) {
  ClhTlsIndex head_index = head_.load(std::memory_order_relaxed);
  ClhTlsNode* head = dereference_qnode(head_index);
  head->succ_must_wait_.store(false, std::memory_order_release);
}
