/*
 * Copyright (c) 2014-2015, Hewlett-Packard Development Company, LP.
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details. You should have received a copy of the GNU General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * HP designates this particular file as subject to the "Classpath" exception
 * as provided by HP in the LICENSE.txt file that accompanied this code.
 */
#ifndef CLHTLS_HPP_
#define CLHTLS_HPP_

#include <atomic>
#include <cassert>
#include <cstring>
#include <memory>

#include "lock_api.hpp"

/**
 * Implements our own extension of Scott's extension of CLH lock
 * (see P62, Figure 4.14 of Scott's Shared-Memory Synchronization).
 * Like K42-TLS, this one uses a central queue-node pool.
 * Likewise, we also use TLS to hold "self" so that we don't need
 * synchronization to determine it each time.
 */

typedef uint32_t ClhTlsIndex;

constexpr ClhTlsIndex kClhTlsNull = 0;
constexpr ClhTlsIndex kClhTlsSentinel = 1;  // or, dummy

/**
 * The node is a bit more complex.
 */
struct ClhTlsNode {
  std::atomic< bool > succ_must_wait_;
  char filler_[256 - sizeof(succ_must_wait_)];

  ClhTlsNode() {
    succ_must_wait_ = false;
  }
};

struct ClhTls {
  /** @returns a unique name that describes the lock algorithm */
  static std::string name() { return "clhtls"; }

  /**
   * Must have a constructor without arguments.
   */
  ClhTls() {
    sentinel_.succ_must_wait_ = false;
    head_ = kClhTlsNull;
    tail_ = kClhTlsSentinel;
  }

  /** We recommend disabling copy constructor to prevent misuse */
  ClhTls(const ClhTls& other) = delete;

  /**
   * Do whatever initialization required to run the experiment.
   * @return will be the return value of main() unless it's 0 (no error).
   */
  int init(
    uint16_t /* socket_count */,
    uint16_t /* in_socket_worker_count */,
    uint32_t /* total_worker_count */) {
    return 0;
  }

  /**
   * Do whatever un-initialization after the experiment.
   * @return will be the return value of main() unless it's 0 (no error).
   */
  int uninit() {
    return 0;
  }

  /**
   * Unconditional lock-acquire for regular user with the given indexes.
   */
  void regular_acquire(
    uint16_t socket_index,
    uint16_t in_socket_worker_index) __attribute__((always_inline));

  /**
   * Lock-release for regular user.
   */
  void regular_release(
    uint16_t socket_index,
    uint16_t in_socket_worker_index) __attribute__((always_inline));

  /**
   * Unconditional lock-acquire for guest user with the given fingerprint
   * (which semi-identifies the guest thread. it might not be unique).
   */
  void guest_acquire(
    uint32_t guest_fingerprint);

  /**
   * Lock-release for guest user.
   */
  void guest_release(
    uint32_t guest_fingerprint);

  /** Print out whatever statistics collected during the experiment. */
  void print_stat();

  /** Defined in cpp */
  ClhTlsIndex borrow_tls_qnode() __attribute__((always_inline));
  ClhTlsNode* dereference_qnode(ClhTlsIndex index) __attribute__((always_inline));

  ClhTlsNode sentinel_;
  std::atomic< ClhTlsIndex >  head_;
  std::atomic< ClhTlsIndex >  tail_;
};

inline void ClhTls::regular_acquire(
  uint16_t /* socket_index */,
  uint16_t /* in_socket_worker_index */) {
  guest_acquire(0);
}

inline void ClhTls::regular_release(
  uint16_t /* socket_index */,
  uint16_t /* in_socket_worker_index */) {
  guest_release(0);
}

#endif  // CLHTLS_HPP_
