/*
 * Copyright (c) 2014-2015, Hewlett-Packard Development Company, LP.
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details. You should have received a copy of the GNU General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * HP designates this particular file as subject to the "Classpath" exception
 * as provided by HP in the LICENSE.txt file that accompanied this code.
 */
#ifndef MCSB_HPP_
#define MCSB_HPP_

#include <numa.h>
#include <stdint.h>

#include <atomic>
#include <cassert>
#include <cstring>
#include <memory>

#include "lock_api.hpp"
#include "mcs.hpp"
#include "util.hpp"

/** the value recommended in cohort locking paper. */
constexpr uint32_t kMcsbMaxInheritance = 64;

/**
 * A variant of MCS-lock that is inspired by C-BO-MCS lock in the cohort-locking paper.
 * The biggest difference is that MCSb doesn't have a local lock for each NUMA node.
 * It just borrows the idea of combining two different lock types.
 *
 * Global-lock is a simple TATAS lock. Guest directly obtains it.
 * Local-lock (kinda) is a MCS lock. But, we don't split it into each NUMA.
 * We have just one usual MCS lock. The winner of this MCS lock moves on to the global
 * lock contention, and then inherits the global lock to successors.
 *
 * We use the value of inherit-limit recommended in the cohort locking paper.
 */
struct Mcsb : public McsBase {
  /**
   * Must have a constructor without arguments.
   */
  Mcsb() {}
  /** We recommend disabling copy constructor to prevent misuse */
  Mcsb(const Mcsb& other) = delete;

  /** @returns a unique name that describes the lock algorithm */
  static std::string name() { return "mcsb"; }

  /**
   * Do whatever initialization required to run the experiment.
   * @return will be the return value of main() unless it's 0 (no error).
   */
  int init(
    uint16_t socket_count,
    uint16_t in_socket_worker_count,
    uint32_t total_worker_count) {
    global_locked_.store(false);
    return init_base(socket_count, in_socket_worker_count, total_worker_count);
  }

  /**
   * Do whatever un-initialization after the experiment.
   * @return will be the return value of main() unless it's 0 (no error).
   */
  int uninit() {
    return uninit_base();
  }

  /**
   * Unconditional lock-acquire on lock_index for regular user with the given indexes.
   */
  void regular_acquire(
    uint16_t socket_index,
    uint16_t in_socket_worker_index) __attribute__((always_inline));

  /**
   * Lock-release for regular user.
   */
  void regular_release(
    uint16_t socket_index,
    uint16_t in_socket_worker_index) __attribute__((always_inline));

  /**
   * Unconditional lock-acquire on lock_index for guest user with the given fingerprint
   * (which semi-identifies the guest thread. it might not be unique).
   */
  void guest_acquire(
    uint32_t guest_fingerprint) __attribute__((always_inline));

  /**
   * Lock-release for guest user.
   */
  void guest_release(
    uint32_t guest_fingerprint) __attribute__((always_inline));

  /** Print out whatever statistics collected during the experiment. */
  void print_stat() {
  }

  /** Separates the cacheine of global_locked_ from MCS tail. */
  char                separator1_[256];
  /** Global-lock part. We don't even back-off. This is a dumb spinlock without backoff. */
  std::atomic< bool > global_locked_;
  char                separator2_[256];
};

inline void Mcsb::regular_acquire(
  uint16_t socket_index,
  uint16_t in_socket_worker_index) {
  std::atomic< McsNodeInt >* me = &qnodes_[socket_index][in_socket_worker_index].node_;
  auto* me_status = &statuses_[socket_index][in_socket_worker_index];
  assert(!me_status->is_waiting());

  me_status->set_waiting(std::memory_order_release);
  me->store(kNullMcsNodeInt, std::memory_order_release);

  const McsNodeInt myself = McsNodeUnion(socket_index, in_socket_worker_index).word;
  McsNodeInt prev = tail_.exchange(myself);
  assert(prev != myself);
  if (prev == kNullMcsNodeInt) {
    // Definitely need to compete at global lock.
    me_status->inherit_count_.store(0, std::memory_order_relaxed);  // only myself sees it. no order
    me_status->set_running(std::memory_order_release);
    ASSERT_NOTEQUAL(tail_.load(), kNullMcsNodeInt);
    guest_acquire(0);  // now compete at global lock
    assert(global_locked_.load());
    return;
  }

  assert(me_status->is_waiting());
  assert(tail_.load() != kNullMcsNodeInt);
  McsNodeUnion prev_union;
  prev_union.word = prev;
  const uint16_t pred_socket = prev_union.component.socket_;
  const uint16_t pred_thread = prev_union.component.thread_;
  assert(pred_socket < socket_count_);
  assert(pred_thread < in_socket_worker_count_);
  assert(pred_socket != socket_index || pred_thread != in_socket_worker_index);
  std::atomic< McsNodeInt >* predecessor = &qnodes_[pred_socket][pred_thread].node_;
  assert(predecessor->load() == kNullMcsNodeInt);
  predecessor->store(myself, std::memory_order_release);

  me_status->spin_while_waiting();
  assert(!me_status->is_waiting());
  ASSERT_NOTEQUAL(tail_.load(), kNullMcsNodeInt);

  auto status_value = me_status->status_.load(std::memory_order_consume);
  if (status_value == McsThreadStatus::kGlobalInherited) {
    // In this case, we are sure we inherited the lock from predecessor
    assert(global_locked_.load());
  } else {
    assert(status_value == McsThreadStatus::kGlobalContested);
    // Needs to acquire it again
    me_status->inherit_count_.store(0, std::memory_order_relaxed);  // only myself sees it. no order
    guest_acquire(0);
  }
}

inline void Mcsb::regular_release(
  uint16_t socket_index,
  uint16_t in_socket_worker_index) {
  std::atomic< McsNodeInt >* me = &qnodes_[socket_index][in_socket_worker_index].node_;
  assert(!statuses_[socket_index][in_socket_worker_index].is_waiting());
  const McsNodeInt myself = McsNodeUnion(socket_index, in_socket_worker_index).word;

  McsNodeInt my_node = me->load(std::memory_order_acquire);
  assert(my_node != myself);
  assert(global_locked_.load());
  if (my_node == kNullMcsNodeInt) {
    McsNodeInt expected = myself;
    if (tail_.compare_exchange_strong(expected, kNullMcsNodeInt)) {
      // NOTE: It's safe to unlock local-MCS and global-TATAS in an asymmetric order.
      // (regular_acquire takes MCS first then global, but regular_release does MCS first)
      // Here, a regular user leaves the global lock taken until the next line, but
      // it doesn't violate correctness because a new regular user is then get blocked
      // at global lock. He will acquire it after the next line. No priorty inversion or whatever.
      guest_release(0);
      return;
    }

    assert(expected != kNullMcsNodeInt);
    assert(expected != myself);

    spin_while([me]{ return me->load(std::memory_order_acquire) == kNullMcsNodeInt; });
    my_node = me->load(std::memory_order_acquire);
  }

  assert(my_node != kNullMcsNodeInt);

  assert(tail_.load() != kNullMcsNodeInt);
  assert(!statuses_[socket_index][in_socket_worker_index].is_waiting());

  McsNodeUnion my_node_union;
  my_node_union.word = my_node;
  const uint16_t socket = my_node_union.component.socket_;
  const uint16_t thread = my_node_union.component.thread_;
  assert(socket < socket_count_);
  assert(thread < in_socket_worker_count_);
  assert(socket != socket_index || thread != in_socket_worker_index);
  auto* successor_status = &statuses_[socket][thread];
  assert(successor_status->is_waiting());

  // Should the successor inherit it?
  auto* me_status = &statuses_[socket_index][in_socket_worker_index];
  uint32_t count = me_status->inherit_count_.load(std::memory_order_relaxed);  // just a hint.
  if (count >= kMcsbMaxInheritance) {
    // we have been holding it too long. Let's release the global lock.
    guest_release(0);
    successor_status->status_.store(McsThreadStatus::kGlobalContested, std::memory_order_release);
  } else {
    // In this case, the successor inherits my global lock. Leave it locked.
    assert(global_locked_.load());
    successor_status->inherit_count_.store(count + 1U, std::memory_order_release);
    successor_status->status_.store(McsThreadStatus::kGlobalInherited, std::memory_order_release);
  }
}

inline void Mcsb::guest_acquire(uint32_t /*guest_fingerprint*/) {
  while (true) {
    bool expected = false;
    if (global_locked_.compare_exchange_weak(expected, true)) {
      break;
    }
  }
  assert(global_locked_.load());
}

inline void Mcsb::guest_release(uint32_t /*guest_fingerprint*/) {
  assert(global_locked_.load());
  global_locked_.store(false);
}

#endif  // MCSB_HPP_
