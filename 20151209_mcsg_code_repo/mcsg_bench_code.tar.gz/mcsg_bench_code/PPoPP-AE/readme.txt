MCSg Bench
----------

There are four experiments in total to generate all the results:

Experiment 1 is for testing MCSg/MCSg++ performs equally well when there are no guests.
Experiment 2 shows that with one guest, MCSg/MCSg++ does not degrade performance much.
Experiment 3 explores the lock throughput with varying number of guests.
Experiment 4 evaluates the ticketing mechanism for preventing priority inversion.

Quick guide
-----------
1. Modify the maximum number of threads to match your system:
   * In ppopp-exp1.sh, adjust the list in line 8 for "users".
   * In ppopp-exp2-3-4.sh, adjust the list in line 9 for "guests", the max value should
     not exceed the total number of threads available (usually 1/2); adjust line 14 for
     total number of threads, it is set to "240" by default.

2. Run experiment scripts:
   $ ./ppopp-exp1.sh && ./ppopp-exp2-3-4.sh.

3. Plot the figures:
   $ cd result
   $ ./plot-exp1.sh && ./plot-exp2.sh && ./plot-exp3.sh && ./plot-exp4.sh

   The figures will be available under result/eps.

4. Cohort lock results (Table 1 in our paper):
   $ cd result
   $ ./compare-cohort-exp1.sh data iter
   It will list lock throughput for MCS, MCSg, MCSg++, and C-MCSg-MCS for with 1 - 240 users.

HyperThreading
--------------
By default mcsgbench assumes HT is on. If, however, it is turned off, give parameter "-htt=0"
after mcsg_bench in pppop-exp1.sh and pppop-exp-2-3-4.sh.

Scripts
-------
pppop-exp1.sh: generates data for experiment 1
pppop-exp2-3-4.sh: generates data for experiments 2, 3, and 4.

In both scripts, we give maximum 240 users (i.e., 240 threads), please adjust this number
if it does not match your system's maximum number of cores.

The scripts will run microbenchmarks with varying number of users (guests/workers) and
different lock algorithms. Results are stored under "result/data".
Both the experiment scripts and plotting scripts will assume 5 runs.

For cohort lock (C-MCSg-MCS), MCSg Bench currently supports up to 18 cores per socket.

