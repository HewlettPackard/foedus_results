#!/bin/bash
# Experiment 2: regular user throughput/guest stdev_ns when there is one guest
# x: number of regular users
# y: throughput of regular users
mkdir -p csv
mkdir -p eps
trap "rm exp2-tmp -fr" EXIT

############ Worker throughput with stdev ###############
export gp_csv="csv/exp2-worker-throughput-hi-contention-stdev.csv"
./summarize-exp2-stdev.sh data/exp3.wc-0.pc-100.tc-100.bind-compact worker iter 5 > $gp_csv
gnuplot ./plt/exp2-worker-throughput-hi-contention-stdev.plt

############ Guest latency #############
export gp_csv="csv/exp2-guest-ave_ns-hi-contention.csv"
./summarize-exp1-3.sh data/exp3.wc-0.pc-100.tc-100.bind-compact guest ave_ns 5 > $gp_csv

# Extract the header and the line for 1 guest
data=`head -2 $gp_csv | tail -1`
header="TATAS K42 MCSg MCSg++ MCSg+" # MCSb" # C-MCSg-MCS"
data=${data//,/ }

# Transpose it and specify color rgb as a separate column for gnuplot
rm -f $gp_csv
i=2

for lock in $header; do
  v=`echo $data | cut -d ' ' -f $i`
  echo -ne "$i,$lock," >> $gp_csv
  v=`echo "scale=3; $v / 1000000" | bc -l` # milisecond
  v=`echo "if ($v < 1) print 0; $v" | bc`
  echo -ne "$v,`expr $i - 1`\n" >> $gp_csv
  ((i++))
done
gnuplot ./plt/exp2-guest-ave_ns-hi-contention.plt

