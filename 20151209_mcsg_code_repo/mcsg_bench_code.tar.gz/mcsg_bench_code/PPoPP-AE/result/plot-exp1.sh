#!/bin/bash
# x: number of regular users
# y: throughput
# For throughput, C-MCSg-MCS is not plotted by default. Turn it on in the last line of exp1-throughput.plt.
mkdir -p csv
mkdir -p eps

# high contention
export gp_csv="csv/exp1-throughput.csv"
./summarize-exp1-3.sh data/exp1.wc-0.pc-100.tc-100.bind-compact worker iter 5 > $gp_csv
gnuplot ./plt/exp1-throughput-hi-contention.plt
