#!/bin/bash
# Experiment 3
# performance metrics vs. changing number of guests
# Total number of thread always= 240
mkdir -p csv
mkdir -p eps

export gp_csv="csv/exp3-total-throughput-hi-contention.csv"
./summarize-exp1-3.sh data/exp3.wc-0.pc-100.tc-100.bind-compact total_throughput 5 > $gp_csv
gnuplot ./plt/exp3-total-throughput-hi-contention.plt

export gp_csv="csv/exp3-guest-throughput-hi-contention.csv"
./summarize-exp1-3.sh data/exp3.wc-0.pc-100.tc-100.bind-compact guest iter 5 > $gp_csv
gnuplot ./plt/exp3-guest-throughput-hi-contention.plt

