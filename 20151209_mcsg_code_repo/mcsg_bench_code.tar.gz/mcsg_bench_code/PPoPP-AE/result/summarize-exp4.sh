#!/bin/bash

reps=5
echo "guests,mcsg+,mcsg++"
for t in 1 2 4 8 15 30 60 90 120
do
  echo -ne "$t"
  for pi in -1 100
  do
    i=0
    total_inv=0
    while [ $i -lt $reps ]; do
      inv=`tail -1 data/exp3.wc-0.pc-100.tc-$pi.bind-compact.mcsg++.$t.$i | cut -d '=' -f2`
      total_inv=`echo "$total_inv + $inv" | bc`
      ((i++))
    done
    echo -ne ,`echo "scale=2; $total_inv / $reps" | bc -l`
  done
  echo
done

