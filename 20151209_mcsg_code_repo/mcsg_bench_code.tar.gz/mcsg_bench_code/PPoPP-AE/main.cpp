/*
 * Copyright (c) 2014-2015, Hewlett-Packard Development Company, LP.
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details. You should have received a copy of the GNU General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * HP designates this particular file as subject to the "Classpath" exception
 * as provided by HP in the LICENSE.txt file that accompanied this code.
 */
#include <numa.h>
#include <gflags/gflags.h>

#include <atomic>
#include <cassert>
#include <chrono>
#include <cmath>
#include <iostream>
#include <mutex>
#include <sstream>
#include <thread>
#include <vector>

#include "lock_api.hpp"

#include "c_mcsg_mcs.hpp"
#include "clh.hpp"
#include "k42.hpp"
#include "mcs.hpp"
#include "mcsg.hpp"
#include "mcsgpp.hpp"
#include "mcsgp.hpp"
#include "rdtsc.hpp"
#include "tatas.hpp"

DEFINE_int64(duration, 10, "Total duration of benchmark in seconds.");
DEFINE_int32(workers, 8, "Number of regular users.");
DEFINE_int32(guests, 1, "Number of guest users.");
DEFINE_int32(protected_cachelines, 4, "How many cachelines to touch in critical section.");
DEFINE_int64(worker_delay, 0, "Nanoseconds to wait after regular user's critical section.");
DEFINE_int64(guest_delay, 0, "Nanoseconds to wait after guest user's critical section.");
DEFINE_int64(mcsgpp_pi_cycle, 0, "Cycles per predecessors to poll in MCSg++. -1 to disable polling.");
DEFINE_int64(mcsgpp_tkt_cycle, 0, "Cycles to poll in MCSg++ when waiting for turns."
  " -1 to disable priority preservation but still collect the number of inversions.");
DEFINE_string(lock, "tatas", "Lock implementation: mcs/mcsg/mcsg++/tatas/clh/mcsb/k42");
DEFINE_bool(htt, true, "Whether to divide # of cores by two to get # of physical cores."
  " There is someway to programatically get it, but I'm lazy. Just receive as a param.");
DEFINE_int64(fixed_mhz,
  // 0,  // Always enable this before pushing to repo
  3000,  // Use this only while debugging
  "Hard-coded CPU MHz. If given, we skip the calibration of RDTSC,"
  " which is handy for debugging.");
DEFINE_bool(verbose, false, "Whehter to print verbose messages.");
DEFINE_string(core_bind, "compact", "Bind threads to hw cores in compact or sparse modes.");

int64_t Mcsgpp::s_mcsgpp_pi_cycle_ = 0;
int64_t Mcsgpp::s_mcsgpp_tkt_cycle_ = 0;
int64_t Mcsgp::s_mcsgp_pi_cycle_ = 0;

struct Stat {
  Stat() : iterations_(0), latency_nanosec_sum_(0), latency_nanosec_sqsum_(0) {}

  void add(uint64_t latency_nanosec) {
    ++iterations_;
    latency_nanosec_sum_ += latency_nanosec;
    latency_nanosec_sqsum_ += latency_nanosec * latency_nanosec;
  }
  void operator+=(const Stat& other) {
    iterations_ += other.iterations_;
    latency_nanosec_sum_ += other.latency_nanosec_sum_;
    latency_nanosec_sqsum_ += other.latency_nanosec_sqsum_;
  }

  uint64_t get_ave_latency_nanosec() const {
    if (iterations_ == 0) {
      return 0;
    }
    return latency_nanosec_sum_ / iterations_;
  }
  uint64_t get_stdev_latency_nanosec() const {
    if (iterations_ <= 1U) {
      return 0;
    }

    uint64_t n = iterations_;
    uint64_t ave_ns = get_ave_latency_nanosec();
    __uint128_t var = latency_nanosec_sqsum_ / (n - 1)
      - (latency_nanosec_sum_ / n) * (latency_nanosec_sum_ / (n - 1));
    if (var == 0) {
      return 0;
    }
    return static_cast<uint64_t>(std::sqrt(static_cast<double>(var)));
  }

  friend std::ostream& operator<<(std::ostream& o, const Stat& v) {
    o << "<iter>" << v.iterations_ << "</iter>"
      << "<ave_ns>" << v.get_ave_latency_nanosec() << "</ave_ns>"
      << "<stdev_ns>" << v.get_stdev_latency_nanosec() << "</stdev_ns>";
    return o;
  }

  uint64_t iterations_;
  __uint128_t latency_nanosec_sum_;
  __uint128_t latency_nanosec_sqsum_;
};

constexpr uint64_t kDiscBucketMax = 1 << 10;
struct DiscrepencyBuckets {
  DiscrepencyBuckets() {
    std::memset(buckets_, 0, sizeof(buckets_));
  }

  void add(int64_t discrepency) {
    if (discrepency >= static_cast<int64_t>(kDiscBucketMax) - 1U) {
      ++buckets_[kDiscBucketMax * 2U - 1U];
    } else if (discrepency <= -static_cast<int64_t>(kDiscBucketMax)) {
      ++buckets_[0];
    } else {
      uint64_t index = discrepency + kDiscBucketMax;
      assert(index < kDiscBucketMax * 2U);
      ++buckets_[index];
    }
  }

  void operator+=(const DiscrepencyBuckets& other) {
    for (auto i = 0; i < kDiscBucketMax * 2U; ++i) {
      buckets_[i] += other.buckets_[i];
    }
  }

  friend std::ostream& operator<<(std::ostream& o, const DiscrepencyBuckets& v) {
    o << "Discrepency-frequency buckets:" << std::endl;
    o << "buckets[-inf]=" << v.buckets_[0] << std::endl;
    for (int64_t i = 1; i < kDiscBucketMax * 2U - 1U; ++i) {
      o << "buckets[" << static_cast<int64_t>(i - kDiscBucketMax)
        << "]=" << v.buckets_[i] << std::endl;
    }
    o << "buckets[inf]=" << v.buckets_[kDiscBucketMax * 2U - 1U] << std::endl;
    return o;
  }

  uint64_t buckets_[kDiscBucketMax * 2U];
};

struct Cacheline {
  Cacheline() : data_(0), counter_(0) {}
  uint64_t data_;  // always dummy
  uint64_t counter_;  // used for inversion stats
  char filler_[64 - sizeof(data_) - sizeof(counter_)];  // 1 cacheline
};

struct ProtectedContent {
  void init(int cacheline_count) {
    cachelines_auto_release_.reset(new Cacheline[cacheline_count]);
    cachelines_ = cachelines_auto_release_.get();
  }

  Cacheline* cachelines_;
  std::unique_ptr< Cacheline[] > cachelines_auto_release_;
};

std::atomic< bool > g_experiment_started;
std::atomic< bool > g_experiment_ended;
std::vector< Stat > g_worker_stats;
std::vector< Stat > g_guest_stats;
std::vector< DiscrepencyBuckets > g_worker_discrepency_buckets;
// std::vector< Stat > g_worker_inversion_stats;  // this one stores "discrepency*1000" instead of ns
double              g_cycles_per_second;
ProtectedContent    g_content;

void busy_sleep(uint64_t nanoseconds) {  // what an oxymoron...
  constexpr uint64_t kNanosecsInSec = 1000000000ULL;

#ifndef NDEBUG
  auto started = std::chrono::high_resolution_clock::now();
#endif  // NDEBUG

  // wait_rdtsc_cycles(g_cycles_per_second * nanoseconds / kNanosecsInSec);
  wait_timer_microseconds(nanoseconds / 1000ULL);

#ifndef NDEBUG
  auto ended = std::chrono::high_resolution_clock::now();
  auto elapsed_ns = std::chrono::duration_cast<std::chrono::nanoseconds>(ended - started).count();
  if (elapsed_ns > nanoseconds * 5U || elapsed_ns < nanoseconds / 5U) {
    std::cerr << "rdtsc_wait too off?? nanosec=" << nanoseconds
      << ". actual=" << elapsed_ns << std::endl;
  }
#endif  // NDEBUG
}

uint64_t __thread t_priority_inversions;
std::atomic<uint64_t> g_total_priority_inversions;

template < typename LOCK_ALGO >
struct BenchDriver {
  static uint64_t content_of_worker_critical_section() {
    for (auto i = 1; i < FLAGS_protected_cachelines; ++i) {
      g_content.cachelines_[i].data_ += i;
    }
    return g_content.cachelines_[0].counter_++;
  }
  static void content_of_guest_critical_section() {
    for (auto i = 0; i < FLAGS_protected_cachelines; ++i) {
      g_content.cachelines_[i].data_ += i;
    }
  }
  static void worker_handler(
    uint16_t socket_index,
    uint16_t in_socket_worker_index,
    uint32_t total_worker_index,
    LOCK_ALGO* algo) {
    assert(socket_index < static_cast<uint32_t>(::numa_num_configured_nodes()));
    ::numa_set_localalloc();

    if (FLAGS_verbose) {
      std::stringstream msg;
      msg << "Started " << socket_index << "-" << in_socket_worker_index
        << "(" << total_worker_index << ")" << std::endl;
      std::cout << msg.str();
    }

    const uint64_t expected_counter_increments = FLAGS_workers;
    uint64_t previous_counter = 0;
    Stat stat;
    DiscrepencyBuckets discrepency_buckets;
    UniformRandom delay_rnd(total_worker_index);
    const uint64_t delay_upto = FLAGS_worker_delay * 2ULL;
    while (!g_experiment_started.load(std::memory_order_acquire)) {}

    while (!g_experiment_ended.load(std::memory_order_acquire)) {
      auto entered = std::chrono::high_resolution_clock::now();

      std::atomic_thread_fence(std::memory_order_acq_rel);
      algo->regular_acquire(socket_index, in_socket_worker_index);
      std::atomic_thread_fence(std::memory_order_acq_rel);

      int64_t actual_counter = content_of_worker_critical_section();

      std::atomic_thread_fence(std::memory_order_acq_rel);
      algo->regular_release(socket_index, in_socket_worker_index);
      std::atomic_thread_fence(std::memory_order_acq_rel);

      auto exitted = std::chrono::high_resolution_clock::now();
      std::chrono::nanoseconds elapsed_nanoseconds = exitted - entered;
      stat.add(elapsed_nanoseconds.count());

      int64_t expected_counter = previous_counter + expected_counter_increments;
      int64_t discrepency = actual_counter - expected_counter;
      discrepency_buckets.add(discrepency);
      previous_counter = actual_counter;

      // Delay interval
      if (delay_upto > 0) {
        busy_sleep(delay_rnd.uniform_upto(delay_upto));
      }
    }

    std::atomic_thread_fence(std::memory_order_seq_cst);
    g_worker_stats[total_worker_index] = stat;
    g_worker_discrepency_buckets[total_worker_index] = discrepency_buckets;
    g_total_priority_inversions += t_priority_inversions;

    if (FLAGS_verbose) {
      std::stringstream msg2;
      msg2 << "Ended " << socket_index << "-" << in_socket_worker_index << std::endl;
      std::cout << msg2.str();
    }
  }
  static void guest_handler(uint32_t guest_index, LOCK_ALGO* algo) {
    if (FLAGS_verbose) {
      std::stringstream msg;
      msg << "Started Guest-" << guest_index << std::endl;
      std::cout << msg.str();
    }

    Stat stat;
    UniformRandom delay_rnd(guest_index + 0x123456789ABCDEFULL);
    const uint64_t delay_upto = FLAGS_guest_delay * 2ULL;
    while (!g_experiment_started.load(std::memory_order_acquire)) {}

    while (!g_experiment_ended.load(std::memory_order_acquire)) {
      auto entered = std::chrono::high_resolution_clock::now();

      std::atomic_thread_fence(std::memory_order_acq_rel);
      algo->guest_acquire(guest_index);
      std::atomic_thread_fence(std::memory_order_acq_rel);

      content_of_guest_critical_section();

      std::atomic_thread_fence(std::memory_order_acq_rel);
      algo->guest_release(guest_index);
      std::atomic_thread_fence(std::memory_order_acq_rel);

      auto exitted = std::chrono::high_resolution_clock::now();
      std::chrono::nanoseconds elapsed_nanoseconds = exitted - entered;
      stat.add(elapsed_nanoseconds.count());

      // guest Delay interval
      if (delay_upto > 0) {
        busy_sleep(delay_rnd.uniform_upto(delay_upto));
      }
    }

    std::atomic_thread_fence(std::memory_order_seq_cst);
    g_guest_stats[guest_index] = stat;

    if (FLAGS_verbose) {
      std::stringstream msg2;
      msg2 << "Ended Guest-" << guest_index << std::endl;
      std::cout << msg2.str();
    }
  }

  static int main_impl() {
    if (::numa_available() < 0) {
      std::cerr << "libnuma not working.";
      return 1;
    }
    if (FLAGS_protected_cachelines < 1) {
      std::cerr << "protected_cachelines must be at least 1";
      return 1;
    }

    if (FLAGS_fixed_mhz) {
      std::cout << "Skipped RDTSC calibration. fixed_mhz=" << FLAGS_fixed_mhz << std::endl;
      g_cycles_per_second = FLAGS_fixed_mhz * 1000000ULL;
    } else {
      std::cout << "Calibrating RDTSC (wait for 15 seconds)..." << std::endl;
      g_cycles_per_second = calibrate_rdtsc_cycles_per_second();
      std::cout << "g_cycles_per_second=" << g_cycles_per_second << std::endl;
    }

    /// Let's allocate explicitly on stack
    /// std::unique_ptr< LOCK_ALGO > algo(new LOCK_ALGO());

    // NOTE: I don't know why, but allocating this on stack vs heap makes a huge difference (35%).
    // And, it differs only when a class that inherits McsBase defines its own member properties.
    // Checked objdump -d with/without that, but the only difference is just one heap allocation
    // address. It's not about false-sharing because having more unused properties (padding)
    // is *slower*. Completely puzzled. Anyway, the issue is resolved by having algo on stack.
    LOCK_ALGO algo;
    auto sockets = ::numa_num_configured_nodes();
    auto hw_cores = std::thread::hardware_concurrency();
    auto cores_per_socket = hw_cores / (sockets * (FLAGS_htt ? 2U : 1U));
    std::cout << "Running experiment:" << algo.name()
      << " sockets=" << sockets
      << " workers=" << FLAGS_workers
      << " guests=" << FLAGS_guests
      << " duration=" << FLAGS_duration
      << " hw_cores=" << hw_cores << "(" << (FLAGS_htt ? "w" : "w/o") << " htt)"
      << " cores_per_socket=" << cores_per_socket
      << std::endl;
    if (FLAGS_workers > cores_per_socket * sockets) {
      std::cerr << "Number of workers large than number of cores" << std::endl;
      return 1;
    }
    int init_ret = algo.init(sockets, cores_per_socket, FLAGS_workers);
    if (init_ret) {
      std::cerr << "init failed.";
      return 1;
    }

    g_experiment_ended.store(false);
    g_experiment_started.store(false);
    g_worker_stats.resize(FLAGS_workers);
    g_guest_stats.resize(FLAGS_guests);
    g_worker_discrepency_buckets.resize(FLAGS_workers);
    g_content.init(FLAGS_protected_cachelines);
    g_total_priority_inversions.store(0);

    std::atomic_thread_fence(std::memory_order_seq_cst);

    std::cout << "Launching workers..." << std::endl;
    std::vector< std::thread > workers;
    for (auto total_worker_index = 0; total_worker_index < FLAGS_workers; ++total_worker_index) {
      auto socket_index = -1;
      uint64_t hw_core_id = -1;
      uint16_t in_socket_worker_index = -1;
      // Assuming dragonhawk mapping, 0,1,...15,90,91...
      // (convenient, phsyical core ID == worker id here, given HTT is enabled)
      // VERY IMPORTANT: Adjust if it's different.
      if (FLAGS_core_bind == "compact") {
        socket_index = total_worker_index / cores_per_socket;
        in_socket_worker_index = total_worker_index - socket_index * cores_per_socket;
        hw_core_id = total_worker_index;
      } else if (FLAGS_core_bind == "sparse") {  // Round robin...
        socket_index = total_worker_index % sockets;
        in_socket_worker_index = total_worker_index / sockets;
        hw_core_id = socket_index * cores_per_socket + in_socket_worker_index;
      } else if (FLAGS_core_bind == "compact1") {
        // THIS DOENS'T WORK WITH GUESTS NOW
        // Same as compact, but skip the last core in each socket. Support up to 224 threads on dh.
        socket_index = total_worker_index / (cores_per_socket-1);
        in_socket_worker_index = total_worker_index - socket_index * (cores_per_socket-1);
        hw_core_id = total_worker_index + (total_worker_index / (cores_per_socket-1));
        std::cout << total_worker_index << " " << hw_core_id << std::endl;
      } else {
        std::cout << "wrong binding type, try -core_bind=compact or sparse.\n";
        return (1);
      }

      workers.emplace_back(
        worker_handler,
        socket_index,
        in_socket_worker_index,
        total_worker_index,
        &algo);

      cpu_set_t cs;
      CPU_ZERO(&cs);
      CPU_SET(hw_core_id, &cs);
      auto s = pthread_setaffinity_np(workers[workers.size()-1].native_handle(), sizeof(cpu_set_t), &cs);
      if (s != 0) {
        std::cout << "error regular user thread binding.\n";
        return 1;
      }
    }

    std::cout << "Launching guests..." << std::endl;
    std::vector< std::thread > guests;
    for (auto guest_index = 0; guest_index < FLAGS_guests; ++guest_index) {
      guests.emplace_back(guest_handler, guest_index, &algo);

      // Note the numa mapping. See comments above for regular users.
      uint64_t hw_core_id = -1;
      if (FLAGS_core_bind == "compact") {
        hw_core_id = FLAGS_workers + guest_index;
      } else if (FLAGS_core_bind == "sparse") {
        auto total_thread_index = FLAGS_workers + guest_index;
        hw_core_id = (total_thread_index % sockets) * cores_per_socket + total_thread_index / sockets;
      } else {
        std::cout << "wrong binding type, try -core_bind=compact or sparse.\n";
        return (1);
      }

      cpu_set_t cs;
      CPU_ZERO(&cs);
      CPU_SET(hw_core_id, &cs);
      auto s = pthread_setaffinity_np(guests[guests.size()-1].native_handle(), sizeof(cpu_set_t), &cs);
      if (s != 0) {
        std::cout << "error guest thread binding.\n";
        return 1;
      }
    }

    std::cout << "Running experiments..." << std::endl;
    auto start_time = std::chrono::system_clock::now();
    auto end_time = start_time + std::chrono::seconds(FLAGS_duration);
    g_experiment_started.store(true);
    while (std::chrono::system_clock::now() < end_time) {
      std::this_thread::sleep_until(end_time);
    }

    auto actual_end_time = std::chrono::system_clock::now();
    std::chrono::nanoseconds experiment_elapsed = actual_end_time - start_time;
    std::cout << "Experiments ended. Took "
      << (experiment_elapsed.count() / 1000000000.0) << " sec" << std::endl;
    g_experiment_ended.store(true);

    for (auto& worker : workers) {
      worker.join();
    }

    for (auto& guest : guests) {
      guest.join();
    }

    int uninit_ret = algo.uninit();
    if (uninit_ret) {
      std::cerr << "uninit failed.";
      return 1;
    }

    Stat worker_total;
    DiscrepencyBuckets discrepency_total;
    for (auto worker_index = 0; worker_index < FLAGS_workers; ++worker_index) {
      if (FLAGS_verbose) {
        std::cout << "worker[" << worker_index << "]=" << g_worker_stats[worker_index] << std::endl;
      }
      worker_total += g_worker_stats[worker_index];
      discrepency_total += g_worker_discrepency_buckets[worker_index];
    }

    Stat guest_total;
    for (auto guest_index = 0; guest_index < FLAGS_guests; ++guest_index) {
      if (FLAGS_verbose) {
        std::cout << "guest[" << guest_index << "]=" << g_guest_stats[guest_index] << std::endl;
      }
      guest_total += g_guest_stats[guest_index];
    }

    auto final_time = std::chrono::system_clock::now();
    std::chrono::nanoseconds wrapup_elapsed = final_time - actual_end_time;

    if (FLAGS_verbose) {
      std::cout << discrepency_total;
    }

    std::cout << "worker_total=" << worker_total << ", guest_total=" << guest_total
        << ", total_throughput=" << (worker_total.iterations_ + guest_total.iterations_)
        << ", experiment_elapsed=" << (experiment_elapsed.count() / 1000000000.0) << "sec"
        << ", wrapup_elapsed=" << (wrapup_elapsed.count() / 1000000000.0) << "sec"
        << std::endl;

    if (FLAGS_lock == "mcsg++") {
      std::cout << "priority_inversions=" << g_total_priority_inversions << std::endl;
    }
    return 0;
  }
};


int main(int argc, char **argv) {
  gflags::SetUsageMessage("MCSg Benchmark");
  gflags::ParseCommandLineFlags(&argc, &argv, true);
  Mcsgpp::s_mcsgpp_pi_cycle_ = FLAGS_mcsgpp_pi_cycle;
  Mcsgpp::s_mcsgpp_tkt_cycle_ = FLAGS_mcsgpp_tkt_cycle;
  Mcsgp::s_mcsgp_pi_cycle_ = FLAGS_mcsgpp_pi_cycle;

  if (FLAGS_lock == "tatas") {
    return BenchDriver<Tatas>::main_impl();
  } else if (FLAGS_lock == "mcs") {
    return BenchDriver<Mcs>::main_impl();
  } else if (FLAGS_lock == "mcsg") {
    return BenchDriver<Mcsg>::main_impl();
  } else if (FLAGS_lock == "mcsg+") {
    return BenchDriver<Mcsgp>::main_impl();
  } else if (FLAGS_lock == "mcsg++") {
    return BenchDriver<Mcsgpp>::main_impl();
  } else if (FLAGS_lock == "c_mcsg_mcs") {
    return BenchDriver<CMcsgMcs>::main_impl();
  } else if (FLAGS_lock == "clh") {
    return BenchDriver<Clh>::main_impl();
  } else if (FLAGS_lock == "k42") {
    return BenchDriver<K42>::main_impl();
  } else {
    std::cerr << "Unrecognized lock type:" << FLAGS_lock << std::endl
      << gflags::ProgramUsage() << std::endl;
    return 1;
  }
}

void Mcsg::pi_spin() {
  poll_bo_while([this]{ return tail_.load(std::memory_order_acquire) == kPiMcsNodeInt; });
}

