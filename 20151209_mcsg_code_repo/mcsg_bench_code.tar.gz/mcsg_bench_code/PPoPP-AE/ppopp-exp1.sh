# Experiment 1 - lock throughput without guests
dir="result/data"
mkdir -p $dir
for b in "compact"
do
  for w in 0; do
    for algo in mcsg++ mcsg mcs tatas clh k42 c_mcsg_mcs; do
      for users in 1 2 4 8 15 30 45 60 90 120 150 180 210 224 240; do
        for pi in 100; do
          for tkt in 100; do
            for rep in 0 1 2 3 4; do
              echo "pi cycle=$pi, tkt cycle=$tkt, wait=$w us, bind=$b, algo=$algo, workers=$users, rep=$rep..."
              ./mcsg_bench -lock $algo -guests 0 -workers $users -worker_delay=$w -guest_delay=$w -mcsgpp_pi_cycle=$pi -mcsgpp_tkt_cycle=$tkt -core_bind=$b -duration=10 &> "$dir/exp1.wc-$w.pc-$pi.tc-$tkt.bind-$b.$algo.$users.$rep"
            done
          done
        done
      done
    done
  done
done
