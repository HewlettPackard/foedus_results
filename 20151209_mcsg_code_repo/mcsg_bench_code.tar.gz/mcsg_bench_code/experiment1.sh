for algo in clh mcsb mcsg mcs mcsg++ tatas k42 k42tls c_mcsg_mcs
do
  for users in 1 2 4 10 15 30 60 90 120 150 180 210 240
  do
    for rep in 0 1 2
    do
      echo "algo=$algo, users=$users, rep=$rep/3..."
      ./mcsg_bench -lock $algo -guests 0 -workers $users -worker_delay=0 &> "20150825-dh/exp1.$algo.$users.$rep"
    done
  done
done

for algo in clh mcsb mcsg mcs mcsg++ tatas k42 k42tls c_mcsg_mcs
do
  for users in 1 2 4 10 15 30 60 90 120 150 180 210 240
  do
    for rep in 0 1 2
    do
      echo "With wait-1us algo=$algo, users=$users, rep=$rep/3..."
      ./mcsg_bench -lock $algo -guests 0 -workers $users -worker_delay=1000 &> "exp1_a.$algo.$users.$rep"
    done
  done
done

for algo in clh mcsb mcsg mcs mcsg++ tatas k42 k42tls c_mcsg_mcs
do
  for users in 1 2 4 10 15 30 60 90 120 150 180 210 240
  do
    for rep in 0 1 2
    do
      echo "With wait-2us algo=$algo, users=$users, rep=$rep/3..."
      ./mcsg_bench -lock $algo -guests 0 -workers $users -worker_delay=2000 &> "exp1_b.$algo.$users.$rep"
    done
  done
done

for algo in clh mcsb mcsg mcs mcsg++ tatas k42 k42tls c_mcsg_mcs
do
  for users in 1 2 4 10 15 30 60 90 120 150 180 210 240
  do
    for rep in 0 1 2
    do
      echo "With wait-5us algo=$algo, users=$users, rep=$rep/3..."
      ./mcsg_bench -lock $algo -guests 0 -workers $users -worker_delay=5000 &> "exp1_c.$algo.$users.$rep"
    done
  done
done
