/*
 * Copyright (c) 2014-2015, Hewlett-Packard Development Company, LP.
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details. You should have received a copy of the GNU General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * HP designates this particular file as subject to the "Classpath" exception
 * as provided by HP in the LICENSE.txt file that accompanied this code.
 */
#ifndef K42TLS_HPP_
#define K42TLS_HPP_

#include <atomic>
#include <cassert>
#include <cstring>
#include <memory>

#include "lock_api.hpp"

/**
 * Implements our own extension of K42 MCS lock that uses TLS to hold
 * a per-thread queue node borrowed from a central queue-node pool.
 *
 * Without such TLS, this algorithm must atomically borrow/return queue-node
 * from the pool for each lock/unlock, which is obviously slow.
 * This implementation depends on an efficient TLS support, such as %fs in
 * x86 and tpidr_el in ARM.
 */

/// unlike stack-version of K42, these are just integers that can work
/// among multiple processes. These integer are indexes in the global pool.
typedef uint32_t K42TlsIndex;

/// The following two values are reserved special values. Never used as
/// a valid index (the pool avoids to use these indexes).
constexpr K42TlsIndex kK42TlsNull = 0;
constexpr K42TlsIndex kK42TlsWaiting = 1;
/** corresponds to "&lock_" in ordinary K42 */
constexpr K42TlsIndex kK42TlsSentinel = 2;

struct K42TlsNode {
  std::atomic< K42TlsIndex > next_;
  std::atomic< K42TlsIndex > tail_;
  char filler_[256 - sizeof(next_) - sizeof(tail_)];

  K42TlsNode() {
    next_.store(kK42TlsNull);
    tail_.store(kK42TlsNull);
  }

  K42TlsNode(K42TlsIndex next, K42TlsIndex tail) {
    next_.store(next);
    tail_.store(tail);
  }
};

struct K42Tls {
  /** @returns a unique name that describes the lock algorithm */
  static std::string name() { return "k42tls"; }

  /**
   * Must have a constructor without arguments.
   */
  K42Tls() {}

  /** We recommend disabling copy constructor to prevent misuse */
  K42Tls(const K42Tls& other) = delete;

  /**
   * Do whatever initialization required to run the experiment.
   * @return will be the return value of main() unless it's 0 (no error).
   */
  int init(
    uint16_t /* socket_count */,
    uint16_t /* in_socket_worker_count */,
    uint32_t /* total_worker_count */) {
    return 0;
  }

  /**
   * Do whatever un-initialization after the experiment.
   * @return will be the return value of main() unless it's 0 (no error).
   */
  int uninit() {
    return 0;
  }

  /**
   * Unconditional lock-acquire for regular user with the given indexes.
   */
  void regular_acquire(
    uint16_t socket_index,
    uint16_t in_socket_worker_index) __attribute__((always_inline));

  /**
   * Lock-release for regular user.
   */
  void regular_release(
    uint16_t socket_index,
    uint16_t in_socket_worker_index) __attribute__((always_inline));

  /**
   * Unconditional lock-acquire for guest user with the given fingerprint
   * (which semi-identifies the guest thread. it might not be unique).
   */
  void guest_acquire(
    uint32_t guest_fingerprint);

  /**
   * Lock-release for guest user.
   */
  void guest_release(
    uint32_t guest_fingerprint);

  /** Print out whatever statistics collected during the experiment. */
  void print_stat();

  /** Defined in cpp */
  K42TlsIndex borrow_tls_qnode() __attribute__((always_inline));
  K42TlsNode* dereference_qnode(K42TlsIndex index) __attribute__((always_inline));

  K42TlsNode lock_;
};

inline void K42Tls::regular_acquire(
  uint16_t /* socket_index */,
  uint16_t /* in_socket_worker_index */) {
  guest_acquire(0);
}

inline void K42Tls::regular_release(
  uint16_t /* socket_index */,
  uint16_t /* in_socket_worker_index */) {
  guest_release(0);
}

#endif  // K42TLS_HPP_
