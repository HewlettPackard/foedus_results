for algo in mcsb mcsg mcsg++ tatas k42 k42tls c_mcsg_mcs
do
  for guests in 1 2 4 5 10 15 30 60 90 120
  do
    for rep in 0 1 2
    do
      echo "With wait-1us algo=$algo, guests=$guests, rep=$rep/3..."
      ./mcsg_bench -lock $algo -guests $guests -workers `expr 240 - $guests` -worker_delay=1000 -guest_delay=1000 -mcsgpp_pi_cycle=100 &> "20150825-dh/exp3.$algo.$guests.$rep"
    done
  done
done
