/*
 * Copyright (c) 2014-2015, Hewlett-Packard Development Company, LP.
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details. You should have received a copy of the GNU General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * HP designates this particular file as subject to the "Classpath" exception
 * as provided by HP in the LICENSE.txt file that accompanied this code.
 */
#ifndef TATAS_HPP_
#define TATAS_HPP_

#include <atomic>
#include <cassert>

#include "lock_api.hpp"

/**
 * The dumbest spin lock.
 */
struct Tatas {
  /**
   * Must have a constructor without arguments.
   */
  Tatas() {
    locked_.store(false);
  }
  /** We recommend disabling copy constructor to prevent misuse */
  Tatas(const Tatas& other) = delete;

  /** @returns a unique name that describes the lock algorithm */
  static std::string name() { return "tatas"; }

  /**
   * Do whatever initialization required to run the experiment.
   * @return will be the return value of main() unless it's 0 (no error).
   */
  int init(
    uint16_t /*socket_count*/,
    uint16_t /*in_socket_worker_count*/,
    uint32_t /*total_worker_count*/) {
    locked_.store(false);
    return 0;
  }

  /**
   * Do whatever un-initialization after the experiment.
   * @return will be the return value of main() unless it's 0 (no error).
   */
  int uninit() {
    return 0;
  }

  /**
   * Unconditional lock-acquire on lock_index for regular user with the given indexes.
   */
  void regular_acquire(
    uint16_t socket_index,
    uint16_t in_socket_worker_index) __attribute__((always_inline));

  /**
   * Lock-release for regular user.
   */
  void regular_release(
    uint16_t socket_index,
    uint16_t in_socket_worker_index) __attribute__((always_inline));

  /**
   * Unconditional lock-acquire on lock_index for guest user with the given fingerprint
   * (which semi-identifies the guest thread. it might not be unique).
   */
  void guest_acquire(
    uint32_t guest_fingerprint) __attribute__((always_inline));

  /**
   * Lock-release for guest user.
   */
  void guest_release(
    uint32_t guest_fingerprint) __attribute__((always_inline));

  /** Print out whatever statistics collected during the experiment. */
  void print_stat() {
  }

  std::atomic<bool> locked_;
};

inline void Tatas::regular_acquire(
  uint16_t /*socket_index*/,
  uint16_t /*in_socket_worker_index*/) {
  guest_acquire(0);
}

inline void Tatas::regular_release(
  uint16_t /*socket_index*/,
  uint16_t /*in_socket_worker_index*/) {
  guest_release(0);
}

inline void Tatas::guest_acquire(uint32_t /*guest_fingerprint*/) {
  while (true) {
    bool expected = false;
    if (locked_.compare_exchange_weak(expected, true)) {
      break;
    }
  }
  assert(locked_.load());
}

inline void Tatas::guest_release(uint32_t /*guest_fingerprint*/) {
  assert(locked_.load());
  locked_.store(false);
}

#endif  // TATAS_HPP_
