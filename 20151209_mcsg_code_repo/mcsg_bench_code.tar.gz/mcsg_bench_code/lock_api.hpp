/*
 * Copyright (c) 2014-2015, Hewlett-Packard Development Company, LP.
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details. You should have received a copy of the GNU General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * HP designates this particular file as subject to the "Classpath" exception
 * as provided by HP in the LICENSE.txt file that accompanied this code.
 */
#ifndef LOCK_API_HPP_
#define LOCK_API_HPP_

#include <stdint.h>

#include <string>

/**
 * This is a dummy class to document what each LOCK_ALGO template class is expected to have.
 * To make a new implementation, copy-paste this class and fill out each method.
 * The whole purpose to not define this class as a virtual interface is performance.
 * We should have no virtual function to avoid overheads in this low-latency experiments.
 */
struct LockApi {
  /** @returns a unique name that describes the lock algorithm */
  static std::string name() { return "foo"; }

  /**
   * Must have a constructor without arguments.
   */
  LockApi();
  /** We recommend disabling copy constructor to prevent misuse */
  LockApi(const LockApi& other) = delete;

  /**
   * Do whatever initialization required to run the experiment.
   * @return will be the return value of main() unless it's 0 (no error).
   */
  int init(
    uint16_t socket_count,
    uint16_t in_socket_worker_count,
    uint32_t total_worker_count);

  /**
   * Do whatever un-initialization after the experiment.
   * @return will be the return value of main() unless it's 0 (no error).
   */
  int uninit();

  /**
   * Unconditional lock-acquire for regular user with the given indexes.
   */
  void regular_acquire(
    uint16_t socket_index,
    uint16_t in_socket_worker_index) __attribute__((always_inline));

  /**
   * Lock-release for regular user.
   */
  void regular_release(
    uint16_t socket_index,
    uint16_t in_socket_worker_index) __attribute__((always_inline));

  /**
   * Unconditional lock-acquire for guest user with the given fingerprint
   * (which semi-identifies the guest thread. it might not be unique).
   */
  void guest_acquire(
    uint32_t guest_fingerprint) __attribute__((always_inline));

  /**
   * Lock-release for guest user.
   */
  void guest_release(
    uint32_t guest_fingerprint) __attribute__((always_inline));

  /** Print out whatever statistics collected during the experiment. */
  void print_stat();

  /// Remember what init() set
  uint16_t socket_count_;
  uint16_t in_socket_worker_count_;
  uint32_t total_worker_count_;
};

#endif  // LOCK_API_HPP_
