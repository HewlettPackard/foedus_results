/*
 * Copyright (c) 2014-2015, Hewlett-Packard Development Company, LP.
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details. You should have received a copy of the GNU General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * HP designates this particular file as subject to the "Classpath" exception
 * as provided by HP in the LICENSE.txt file that accompanied this code.
 */
#ifndef MCSGPP_HPP_
#define MCSGPP_HPP_

#include <numa.h>
#include <stdint.h>

#include <algorithm>
#include <atomic>
#include <cassert>
#include <cstring>
#include <memory>

#include "lock_api.hpp"
#include "mcs.hpp"
#include "mcsg.hpp"
#include "util.hpp"

constexpr uint16_t kMuThread    = 0xFFFDU;
constexpr uint16_t kEtaThread   = 0xFFFCU;
constexpr uint16_t kSigmaThread = 0xFFFBU;
constexpr uint16_t kOmegaThread = 0xFFFAU;

/**
 * \f$\mu\f$ is used only in regular user's qnode.
 * This special value is put by a guest who holds the lock
 * to notify the leader of a regular user group whose
 * tail is currently put in MCS lock-tail.
 * The guest does atomic XCHG in its release to obtain exactly one such tail,
 * waking up the leader of the tail group.
 * Unless the MCS lock-tail is still \f$\pi\f$ (meaning there is no one else),
 * it is guaranteed that there is exactly one group who \e stole the \f$\pi\f$
 * and waiting for this \f$\mu\f$ value. And, as of XCHG-ing the tail,
 * the tail of such a group is finalized to be the value the guest observed.
 * Therefore, it's safe for the guest to put \f$\mu\f$ to the tail.
 */
const McsNodeInt kMuNodeInt     = McsNodeUnion(kPiMcsNodeInt, kMuThread).word;
/**
 * \f$\eta\f$ is used only in regular user's qnode.
 * A guest installs this value to the qnode of the regular user it follows.
 * When the regular user releases the lock, it writes \f$\sigma\f$
 * to notify the guest instead of another regular user.
 */
const McsNodeInt kEtaNodeInt    = McsNodeUnion(kPiMcsNodeInt, kEtaThread).word;
/**
 * \f$\sigma\f$ is used only in regular user's qnode.
 * \f$\sigma\f$ overwrites \f$\eta\f$ to notify the waiting guest that
 * the regular user has released the lock. The guest then writes back \f$\omega\f$.
 */
const McsNodeInt kSigmaNodeInt  = McsNodeUnion(kPiMcsNodeInt, kSigmaThread).word;
/**
 * \f$\omega\f$ is used only in regular user's qnode.
 * This the last state of the \f$\eta \rightarrow \sigma \rightarrow \omega\f$
 * transition. The guest user writes this back to notify the regular user
 * that it did observe \f$\sigma\f$ and now the qnode is truly unused, thus ready for reuse.
 * Without this value, the regular user might move too quickly such that it
 * overwrites \f$\sigma\f$ the guest didn't pick up yet.
 */
const McsNodeInt kOmegaNodeInt  = McsNodeUnion(kPiMcsNodeInt, kOmegaThread).word;

inline void assert_not_mcsgpp_special_value(McsNodeInt value) {
  // Assert one by one so that we can know which value it was
  assert(value != kPiMcsNodeInt);
  assert(value != kMuNodeInt);
  assert(value != kEtaNodeInt);
  assert(value != kSigmaNodeInt);
  assert(value != kOmegaNodeInt);
}

extern uint64_t __thread t_priority_inversions;

/**
 * An extention of MCS-g that addresses a few issues at the cost of more complexity.
 * \li Guest starvation is addressed by using XCHG and a few more special values.
 * \li Priority inversion among regular groups are addressed by dynamic poll intervals
 * based on hints on a separate memory.
 *
 * There should be no drawback compared to MCSg in terms of regular user's performance
 * when there are no guests. The only possible drawback (aside from code complexity) appears
 * when there are guests.
 */
struct Mcsgpp : public McsBase {
  /**
   * Must have a constructor without arguments.
   */
  Mcsgpp() {}
  /** We recommend disabling copy constructor to prevent misuse */
  Mcsgpp(const Mcsgpp& other) = delete;

  /** @returns a unique name that describes the lock algorithm */
  static std::string name() { return "mcsg++"; }

  /**
   * Do whatever initialization required to run the experiment.
   * @return will be the return value of main() unless it's 0 (no error).
   */
  int init(
    uint16_t socket_count,
    uint16_t in_socket_worker_count,
    uint32_t total_worker_count) {
    pi_next_ticket_.store(1);
    pi_ticket_owner.store(1);
    t_priority_inversions = 0;
    return init_base(socket_count, in_socket_worker_count, total_worker_count);
  }

  /**
   * Do whatever un-initialization after the experiment.
   * @return will be the return value of main() unless it's 0 (no error).
   */
  int uninit() {
    return uninit_base();
  }

  /**
   * Unconditional lock-acquire on lock_index for regular user with the given indexes.
   */
  void regular_acquire(
    uint16_t socket_index,
    uint16_t in_socket_worker_index) __attribute__((always_inline));
  /** subroutine in case the regular user observed Pi */
  void regular_acquire_pi_case(
    uint16_t socket_index,
    uint16_t in_socket_worker_index,
    McsNodeInt& my_group_tail) __attribute__((noinline));  // because only when UNLIKELY
  /** subroutine in case the regular user waits for an "obvious" Pi value to go away */
  void regular_acquire_spin_while_pi();
  static int64_t s_mcsgpp_pi_cycle_;
  static int64_t s_mcsgpp_tkt_cycle_;

  /**
   * Lock-release for regular user.
   */
  void regular_release(
    uint16_t socket_index,
    uint16_t in_socket_worker_index) __attribute__((always_inline));
  /** subroutine in case the regular user observed Eta */
  void regular_release_eta_case(
    uint16_t socket_index,
    uint16_t in_socket_worker_index) __attribute__((noinline));  // because only when UNLIKELY

  /**
   * Unconditional lock-acquire on lock_index for guest user with the given fingerprint
   * (which semi-identifies the guest thread. it might not be unique).
   */
  void guest_acquire(
    uint32_t guest_fingerprint) __attribute__((always_inline));

  /**
   * Lock-release for guest user.
   */
  void guest_release(
    uint32_t guest_fingerprint) __attribute__((always_inline));

  /** Print out whatever statistics collected during the experiment. */
  void print_stat() {
  }

  // separates cacheline
  char padding1_[256 - (sizeof(McsBase) % 256U)];

  /**
   * Remiscent to a ticket lock, for reducing priority inversions.
   * Changes in regular_acquire only:
   * 1. Get a ticket
   * 2. Wait for my turn when retrying
   * 3. Increment the "now serving" field after got my turn
   */
  // Tickets start from 1
  std::atomic<uint16_t> pi_next_ticket_;  // The "ticket dispenser"
  std::atomic<uint16_t> pi_ticket_owner;  // "Now serving"
  char padding2_[256 - sizeof(std::atomic<uint16_t>) * 2];
};

inline void Mcsgpp::regular_acquire(
  uint16_t socket_index,
  uint16_t in_socket_worker_index) {
  std::atomic< McsNodeInt >* me = &qnodes_[socket_index][in_socket_worker_index].node_;
  auto* me_status = &statuses_[socket_index][in_socket_worker_index];
  // assert(!me_status->is_waiting());

  // me_status->set_waiting(std::memory_order_release);
  me->store(kNullMcsNodeInt, std::memory_order_release);
  const McsNodeInt myself = McsNodeUnion(socket_index, in_socket_worker_index).word;
  McsNodeInt my_group_tail = myself;
  McsNodeInt prev_tail = kNullMcsNodeInt;
  uint32_t myticket = 0;
  while (true) {
    // if it's obviously locked by a guest, we should wait until it's released.
    // In MCS-g++, we consider how many groups have entered recently.
    // In MCSgp/gpp with guests, having \pi in the lock tail is a norm under
    // high contention. So we need to poll here (unlike MCSg, which doesn't need
    // to poll here).
    if (s_mcsgpp_pi_cycle_ >= 0 && UNLIKELY(tail_.load(std::memory_order_acquire) == kPiMcsNodeInt)) {
      poll_while(
        [this]{ return tail_.load(std::memory_order_acquire) == kPiMcsNodeInt; },
        s_mcsgpp_pi_cycle_);
    }

    // Wait for my turn
    // XXX(tzwang): there is a trade-off between reducing priority inversion and giving
    // more priority to guests: if we poll here, chances are guests will grab the lock
    // when we're waiting for turns.
    if (s_mcsgpp_tkt_cycle_ >= 0 && myticket != 0) {
      // Under high contention, this should be as fast as possible, so don't poll
      while (myticket != pi_ticket_owner.load(std::memory_order_acquire)) {}
      //poll_while(
      //  [this,myticket]{ return myticket != pi_ticket_owner.load(std::memory_order_acquire); },
      //  s_mcsgpp_tkt_cycle_);
    }

    prev_tail = tail_.exchange(my_group_tail);
    if (prev_tail == kNullMcsNodeInt) {
      // me_status->set_running(std::memory_order_release);
      ASSERT_NOTEQUAL(tail_.load(), kNullMcsNodeInt);
      if (myticket != 0) {
        if (++pi_ticket_owner == 0) {  // overfolwed
          pi_ticket_owner++;
        }
      }
      return;
    } else if (UNLIKELY(prev_tail == kPiMcsNodeInt)) {
      if (myticket == 0) {
        do {
          myticket = pi_next_ticket_.fetch_add(1, std::memory_order_release);
        } while (myticket == 0);  // pi_next_ticket_ overflowed
      }
      assert(myticket > 0);
      regular_acquire_pi_case(in_socket_worker_index, in_socket_worker_index, my_group_tail);
      continue;
    } else {
      // Joining another group's tail, priority inversed
      if (myticket != 0) {
        if (++pi_ticket_owner == 0) {  // overflowed
          pi_ticket_owner++;
        }
        t_priority_inversions++;
      }
      break;
    }
  }

  // Joined a regular user. Usual MCS lock-acuiqre
  assert(prev_tail != myself);
  assert(prev_tail != my_group_tail);
  assert_not_mcsgpp_special_value(prev_tail);
  assert(prev_tail != kNullMcsNodeInt);
  // assert(me_status->is_waiting());

  McsNodeUnion prev_union;
  prev_union.word = prev_tail;
  const uint16_t pred_socket = prev_union.component.socket_;
  const uint16_t pred_thread = prev_union.component.thread_;
  assert(pred_socket < socket_count_);
  assert(pred_thread < in_socket_worker_count_);
  assert(pred_socket != socket_index || pred_thread != in_socket_worker_index);
  std::atomic< McsNodeInt >* predecessor = &qnodes_[pred_socket][pred_thread].node_;
  ASSERT_EQUAL(predecessor->load(), kNullMcsNodeInt);
  me_status->set_waiting(std::memory_order_release);
  predecessor->store(myself, std::memory_order_release);

  me_status->spin_while_waiting();
  assert(!me_status->is_waiting());
}

inline void Mcsgpp::regular_acquire_pi_case(
  uint16_t socket_index,
  uint16_t in_socket_worker_index,
  McsNodeInt& my_group_tail) {
  // Unlike MCS-g, we do NOT have to return the \pi here.
  // Instead, we expect the guest to observe my_group_tail and
  // puts \mu to the qnode of my_group_tail.

  // Note that we might have to update the value of my_group_tail by further
  // following the chain. Suppose T1,T2,T3,Guest:
  //  1. Guest acquired. NULL -> Pi
  //  2. T1 joined. Pi -> 1 (XCHG), T1 observes Pi and comes here (my_group_tail=1).
  //  3. T2 joined. 1 -> 2 (XCHG), T2 observes 1 and append itself to T1.
  //  4. Guest releases. 2 -> NULL (XCHG). Guest observes 2, and put Mu to T2.
  // T1's qnode says "2", T2's qnode says "Mu", but T1's my_group_tail is still 1.
  // So, T1 must follow the chain until it finds Mu.
  while (true) {
    if (my_group_tail == kPiMcsNodeInt) {
      // We're retrying with a guest in the end of my group
      // FIXME(tzwang): maybe poll for while instead of retrying immediately
      break;
    }

    assert(my_group_tail != kNullMcsNodeInt);
    assert_not_mcsgpp_special_value(my_group_tail);

    McsNodeUnion my_tail_union;
    my_tail_union.word = my_group_tail;
    const uint16_t my_tail_socket = my_tail_union.component.socket_;
    const uint16_t my_tail_thread = my_tail_union.component.thread_;
    assert(my_tail_socket < socket_count_);
    assert(my_tail_thread < in_socket_worker_count_);
    std::atomic< McsNodeInt >* my_tail = &qnodes_[my_tail_socket][my_tail_thread].node_;

    // Here, we are spinnign on the group-tail's qnode, which might not be my own qnode.
    // Thus, it can be on remote NUMA node. ouch.
    // However, only the group-leader is doing that, and it happens only when there is a guest.
    // So, still the primary benefit of MCS-lock is guaranteed.
    if (my_tail->load(std::memory_order_acquire) == kNullMcsNodeInt) {
      spin_while([my_tail]{
        return my_tail->load(std::memory_order_acquire) == kNullMcsNodeInt;
      });
    }

    McsNodeInt next_tail = my_tail->load(std::memory_order_acquire);
    assert(next_tail != kNullMcsNodeInt);
    if (next_tail == kMuNodeInt) {
      ASSERT_EQUAL(my_tail->load(), kMuNodeInt);
      // Now this group will retry.
      // Unlike MCSg, MCSg++ "kept" the \pi value this group stole.
      // Rather than returning it, the leader completed the responsibility of \pi value
      // by waiting for and consuming the \mu value in the group-tail's qnode.
      // Hence, this group is now equivalent to a group that is newly re-joining the group
      // as if the previous XCHG didn't happen.
      // We thus forget (reset) the \mu value of the group-tail and continue.
      my_tail->store(kNullMcsNodeInt);
      break;
    } else if (next_tail == kEtaNodeInt) {
      ASSERT_EQUAL(my_tail->load(), kEtaNodeInt);
      // So a guest is waiting at the end of my group.
      // We need to retry by putting \pi in the lock tail, so that other new regular
      // users are able to form a new group and (hopefully) follow the above
      // next_tail=\mu case if there's no more guests.
      my_group_tail = kPiMcsNodeInt;
      break;
    }

    // Otherwise follow to the next successor
    assert_not_mcsgpp_special_value(next_tail);
    my_group_tail = next_tail;
  }
}

inline void Mcsgpp::regular_release(
  uint16_t socket_index,
  uint16_t in_socket_worker_index) {
  std::atomic< McsNodeInt >* me = &qnodes_[socket_index][in_socket_worker_index].node_;
  assert(!statuses_[socket_index][in_socket_worker_index].is_waiting());
  const McsNodeInt myself = McsNodeUnion(socket_index, in_socket_worker_index).word;

  // Check my node value to avoid unnecessary atomic CAS.
  // We are sure that once my node becomes non-null, it never becomes null.
  McsNodeInt my_node = me->load(std::memory_order_acquire);
  if (my_node == kNullMcsNodeInt) {
    McsNodeInt expected = myself;
    if (LIKELY(tail_.compare_exchange_strong(expected, kNullMcsNodeInt))) {
      // Despite all the differences from the original MCS, there is one invariant that still holds.
      // Iff the tail value is my qnode, I have no duty to notify anyone on releasing the lock.
      ASSERT_EQUAL(me->load(), kNullMcsNodeInt);
      return;
    } else {
      // In other words, because the CAS above failed, I surely _DO_ have a duty to notify someone.
      // Thus, I can safely spin until someone installs successor-information in my qnode.
      // (If the above invariant doesn't hold, this would result in an infinite wait!)
      spin_while([me]{ return me->load(std::memory_order_acquire) == kNullMcsNodeInt; });
      my_node = me->load(std::memory_order_acquire);
    }
  }

  assert(my_node != kNullMcsNodeInt);
  assert(my_node != kMuNodeInt);
  assert(my_node != kSigmaNodeInt);
  assert(my_node != kOmegaNodeInt);
  assert(my_node != kPiMcsNodeInt);
  assert(my_node != myself);
  if (UNLIKELY(my_node == kEtaNodeInt)) {
    // I'm followed by a guest. Let's wake him up.
    regular_release_eta_case(socket_index, in_socket_worker_index);
    return;
  }

  // I'm followed by a regular user. Usual MCS unlock
  assert_not_mcsgpp_special_value(my_node);
  McsNodeUnion my_node_union;
  my_node_union.word = my_node;
  const uint16_t socket = my_node_union.component.socket_;
  const uint16_t thread = my_node_union.component.thread_;
  assert(socket < socket_count_);
  assert(thread < in_socket_worker_count_);
  assert(socket != socket_index || thread != in_socket_worker_index);
  auto* successor_status = &statuses_[socket][thread];
  assert(successor_status->is_waiting());
  successor_status->set_running(std::memory_order_release);
}

inline void Mcsgpp::regular_release_eta_case(
  uint16_t socket_index,
  uint16_t in_socket_worker_index) {
  // I'm followed by a guest. Let's wake him up.
  std::atomic< McsNodeInt >* me = &qnodes_[socket_index][in_socket_worker_index].node_;
  me->store(kSigmaNodeInt, std::memory_order_release);

  // Before returning, we have to make sure the guest picked it up.
  // Otherwise, we might overwrite this qnode before he picks it up.
  spin_while([me]{ return me->load(std::memory_order_acquire) != kOmegaNodeInt; });
  ASSERT_EQUAL(me->load(), kOmegaNodeInt);
}

inline void Mcsgpp::guest_acquire(uint32_t /*guest_fingerprint*/) {
  while (true) {
    /*
    // Try the best to attach after a regular user, instead of grabbing the
    // lock directly when it's NULL (not very useful for hi-contention)
    int counter = 0;
    while (true) {
      auto t = tail_.load(std::memory_order_acquire);
      if (t == kPiMcsNodeInt) {
        poll_bo_while([this]{ return tail_.load(std::memory_order_acquire) == kPiMcsNodeInt; });
        continue;
      }
      else if (t == kNullMcsNodeInt) {
        if (counter++ >= 50) {
          break;
        }
      }
      else {
        break;
      }
    }
    */

    // If another guest is the tail, we anyway have to wait. do that now.
    if (tail_.load(std::memory_order_acquire) == kPiMcsNodeInt) {
      poll_bo_while([this]{ return tail_.load(std::memory_order_acquire) == kPiMcsNodeInt; });
    }

    McsNodeInt prev_tail = tail_.exchange(kPiMcsNodeInt);
    if (prev_tail == kNullMcsNodeInt) {
      // We got the lock, easy.
      return;
    } else if (prev_tail == kPiMcsNodeInt) {
      continue;
    } else {
      // We follow a regular user. Let the predecessor know about us.
      McsNodeUnion prev_union;
      prev_union.word = prev_tail;
      const uint16_t socket = prev_union.component.socket_;
      const uint16_t thread = prev_union.component.thread_;
      assert(socket < socket_count_);
      assert(thread < in_socket_worker_count_);

      std::atomic< McsNodeInt >* prev = &qnodes_[socket][thread].node_;
      assert_not_mcsgpp_special_value(prev->load());
      ASSERT_EQUAL(prev->load(), kNullMcsNodeInt);
      prev->store(kEtaNodeInt);

      // wait until the regular user changes it to \sigma
      spin_while([prev]{ return prev->load(std::memory_order_acquire) != kSigmaNodeInt; });
      ASSERT_EQUAL(prev->load(), kSigmaNodeInt);

      // Now let the regular user know that he can really go away, potentially reusing the qnode.
      prev->store(kOmegaNodeInt, std::memory_order_release);
      return;
    }
  }
}

inline void Mcsgpp::guest_release(uint32_t /*guest_fingerprint*/) {
  // Observe that we do a very unusual thing here as a MCS lock-release.
  // We *XCHG*, not CAS, the tail to check whether/who we should notify of this release.
  // When there are multiple groups, this XCHG captures the last group,
  // so this can cause priorty inversion between groups.
  McsNodeInt prev_tail = tail_.exchange(kNullMcsNodeInt);
  assert(prev_tail != kNullMcsNodeInt);
  if (prev_tail == kPiMcsNodeInt) {
    // Trivial release case. No regular groups that are waiting for my notification
    return;
  }

  // we have a regular group whose leader is guaranteed to be waiting at this lock
  // (because I hold the lock). Wake him up by \mu value.
  McsNodeUnion prev_union;
  prev_union.word = prev_tail;
  const uint16_t socket = prev_union.component.socket_;
  const uint16_t thread = prev_union.component.thread_;
  assert(socket < socket_count_);
  assert(thread < in_socket_worker_count_);

  std::atomic< McsNodeInt >* prev = &qnodes_[socket][thread].node_;
  assert(prev->load() == kNullMcsNodeInt);

  // Let the tail-group know that their leader can now retry acquiring the lock.
  prev->store(kMuNodeInt);
}

#endif  // MCSGPP_HPP_
