/*
 * Copyright (c) 2014-2015, Hewlett-Packard Development Company, LP.
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details. You should have received a copy of the GNU General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * HP designates this particular file as subject to the "Classpath" exception
 * as provided by HP in the LICENSE.txt file that accompanied this code.
 */
#ifndef C_MCSG_MCS_HPP_
#define C_MCSG_MCS_HPP_

#include <numa.h>
#include <stdint.h>

#include <atomic>
#include <cassert>
#include <cstring>
#include <memory>

#include "lock_api.hpp"
#include "mcs.hpp"
#include "mcsgpp.hpp"
#include "util.hpp"

/** the value recommended in cohort locking paper. */
constexpr uint32_t kCMcsgMcsMaxInheritance = 64;

/** to simplify the code. yes I'm lazy.*/
constexpr uint16_t kMaxSockets = 16U;

/** to simplify the code. yes I'm very lazy.*/
constexpr uint32_t kThreadGlobalQnodePoolSize = 1U << 12;

/** to simplify the code. yes I'm extremely lazy.*/
constexpr uint16_t kMaxThreadsPerSocket = 16U;

/**
 * Only used in ThreadGlobalQNodePool to denote which QNode is not used currently.
 */
const McsNodeInt kMcsUnusedQnode = McsNodeUnion(kNullSocket, kNullThread, 0xFFFFFFFFU).word;

/**
 * A cohort lock whose global lock is MCSg
 * and whose local lock is MCS.
 * This is a special implementation different from others in the sense that
 * it's not in the same category. All other implementations need only one shared place
 * while this lock needs multiple "local" places, which is harder to use in, say, databases
 * which cannot know how many lock objects they need beforehand.
 *
 * Rather, this implementation is to demonstrate MCSg/MCSg++ is orthogonal to cohorting,
 * thus can be useful on top of cohorting.
 */
struct CMcsgMcs {
  struct ThreadGlobalQNodePool {
    /**
     * Used only by the owner thread.
     * This is just a hint to search for next usable qnode index.
     */
    uint64_t              next_qnode_index_;

    std::atomic< McsNodeInt > pooled_qnodes_[kThreadGlobalQnodePoolSize];
  };

  struct LocalLock {
    std::atomic< McsNodeInt > tail_;

    char                      separator_[256 - sizeof(tail_)];

    ThreadGlobalQNodePool     global_qnode_pools_[kMaxThreadsPerSocket];
  };
  typedef LocalLock* LocalLockPtr;

  /**
   * Must have a constructor without arguments.
   */
  CMcsgMcs() {
    std::memset(local_locks_, 0, sizeof(LocalLockPtr) * kMaxSockets);
  }
  /** We recommend disabling copy constructor to prevent misuse */
  CMcsgMcs(const CMcsgMcs& other) = delete;

  /** @returns a unique name that describes the lock algorithm */
  static std::string name() { return "c_mcsg_mcs"; }

  /**
   * Do whatever initialization required to run the experiment.
   * @return will be the return value of main() unless it's 0 (no error).
   */
  int init(
    uint16_t socket_count,
    uint16_t in_socket_worker_count,
    uint32_t total_worker_count) {
    socket_count_ = socket_count;
    in_socket_worker_count_ = in_socket_worker_count;
    total_worker_count_ = total_worker_count;
    global_tail_.store(kNullMcsNodeInt);
    qnodes_array_auto_release_.reset(new FatMcsNode*[socket_count]);
    qnodes_ = qnodes_array_auto_release_.get();
    statuses_array_auto_release_.reset(new FatMcsThreadStatus*[socket_count]);
    statuses_ = statuses_array_auto_release_.get();
    for (auto socket = 0; socket < socket_count; ++socket) {
      qnodes_[socket] = reinterpret_cast<FatMcsNode*>(
        ::numa_alloc_onnode(sizeof(FatMcsNode) * in_socket_worker_count, socket));
      std::memset(qnodes_[socket], 0, sizeof(FatMcsNode) * in_socket_worker_count);
      statuses_[socket] = reinterpret_cast<FatMcsThreadStatus*>(
        ::numa_alloc_onnode(sizeof(FatMcsThreadStatus) * in_socket_worker_count, socket));
      std::memset(statuses_[socket], 0, sizeof(FatMcsThreadStatus) * in_socket_worker_count);
      for (auto thread_index = 0; thread_index < in_socket_worker_count; ++thread_index) {
        qnodes_[socket][thread_index].node_.store(kNullMcsNodeInt);
        statuses_[socket][thread_index].init();
      }

      local_locks_[socket]
        = reinterpret_cast<LocalLockPtr>(::numa_alloc_onnode(sizeof(LocalLock), socket));
      std::memset(local_locks_[socket], 0, sizeof(LocalLock));
      local_locks_[socket]->tail_.store(kNullMcsNodeInt);
      for (auto thread_index = 0; thread_index < in_socket_worker_count; ++thread_index) {
        for (auto q = 0; q < kThreadGlobalQnodePoolSize; ++q) {
          local_locks_[socket]->global_qnode_pools_[thread_index].
            pooled_qnodes_[q].store(kMcsUnusedQnode);
        }
      }
    }
    return 0;
  }

  /**
   * Do whatever un-initialization after the experiment.
   * @return will be the return value of main() unless it's 0 (no error).
   */
  int uninit() {
    if (qnodes_) {
      for (auto socket = 0; socket < socket_count_; ++socket) {
        if (qnodes_[socket]) {
          ::numa_free(qnodes_[socket], sizeof(FatMcsNode) * in_socket_worker_count_);
          qnodes_[socket] = nullptr;
        }
      }
      qnodes_array_auto_release_.reset(nullptr);
      qnodes_ = nullptr;
    }

    if (statuses_) {
      for (auto socket = 0; socket < socket_count_; ++socket) {
        if (statuses_[socket]) {
          ::numa_free(statuses_[socket], sizeof(FatMcsThreadStatus) * in_socket_worker_count_);
          statuses_[socket] = nullptr;
        }
      }
      statuses_array_auto_release_.reset(nullptr);
      statuses_ = nullptr;
    }

    for (auto i = 0; i < kMaxSockets; ++i) {
      if (local_locks_[i]) {
        ::numa_free(local_locks_[i], sizeof(LocalLock));
        local_locks_[i] = nullptr;
      }
    }
    return 0;
  }

  /**
   * Unconditional lock-acquire on lock_index for regular user with the given indexes.
   */
  void regular_acquire(
    uint16_t socket_index,
    uint16_t in_socket_worker_index) __attribute__((always_inline));
  McsThreadStatus regular_local_acquire(
    uint16_t socket_index,
    uint16_t in_socket_worker_index) __attribute__((always_inline));

  /**
   * Lock-release for regular user.
   */
  void regular_release(
    uint16_t socket_index,
    uint16_t in_socket_worker_index) __attribute__((always_inline));
  void regular_release_global(
    uint16_t socket_index,
    uint16_t in_socket_worker_index) __attribute__((always_inline));

  /**
   * Unconditional lock-acquire on lock_index for guest user with the given fingerprint
   * (which semi-identifies the guest thread. it might not be unique).
   */
  void guest_acquire(
    uint32_t guest_fingerprint) __attribute__((always_inline));

  /**
   * Lock-release for guest user.
   */
  void guest_release(
    uint32_t guest_fingerprint) __attribute__((always_inline));

  /** Print out whatever statistics collected during the experiment. */
  void print_stat() {
  }

  std::atomic< McsNodeInt >* to_global_qnode(McsNodeUnion id)  __attribute__((always_inline));
  void release_global_qnode(McsNodeUnion id)  __attribute__((always_inline));
  uint32_t next_global_qnode_index(
    uint16_t socket_index,
    uint16_t in_socket_worker_index) __attribute__((always_inline));


  uint16_t socket_count_;
  uint16_t in_socket_worker_count_;
  uint32_t total_worker_count_;

  /**
   * qnodes[socket][thread] is the QNode of the specified thread.
   * qnodes[socket] is an array allocated in the socket using libnuma.
   */
  FatMcsNode** qnodes_;
  std::unique_ptr< FatMcsNode*[] > qnodes_array_auto_release_;

  /** waiting_ bool flag for each thread. similar to above */
  FatMcsThreadStatus** statuses_;
  std::unique_ptr< FatMcsThreadStatus*[] > statuses_array_auto_release_;

  LocalLockPtr        local_locks_[kMaxSockets];

  /// everything above are read-only once init-ed. let's separate the cachelines.
  char                separator1_[256];
  std::atomic< McsNodeInt > global_tail_;
  char                separator2_[256 - sizeof(global_tail_)];
};

inline McsThreadStatus CMcsgMcs::regular_local_acquire(
  uint16_t socket_index,
  uint16_t in_socket_worker_index) {
  auto* buddy_qnodes = qnodes_[socket_index];
  auto* local_me = &buddy_qnodes[in_socket_worker_index].local_node_;
  auto* me_status = &statuses_[socket_index][in_socket_worker_index];
  auto* local_tail = local_locks_[socket_index];
  assert(!me_status->is_waiting());

  me_status->set_waiting(std::memory_order_release);
  local_me->store(kNullMcsNodeInt, std::memory_order_release);

  const McsNodeInt myself = McsNodeUnion(socket_index, in_socket_worker_index).word;
  McsNodeInt prev = local_tail->tail_.exchange(myself);
  assert(prev != myself);
  if (prev == kNullMcsNodeInt) {
    // Definitely need to compete at global lock.
    return McsThreadStatus::kGlobalContested;
  }

  assert(me_status->is_waiting());
  assert(local_tail->tail_.load() != kNullMcsNodeInt);
  McsNodeUnion prev_union;
  prev_union.word = prev;
  const uint16_t pred_socket = prev_union.component.socket_;
  const uint16_t pred_thread = prev_union.component.thread_;
  assert(prev_union.component.qnode_index_ == 0);
  assert(pred_socket == socket_index);  // must be a buddy
  assert(pred_thread < in_socket_worker_count_);
  assert(pred_thread != in_socket_worker_index);
  std::atomic< McsNodeInt >* predecessor = &buddy_qnodes[pred_thread].local_node_;
  assert(predecessor->load() == kNullMcsNodeInt);
  predecessor->store(myself, std::memory_order_release);

  me_status->spin_while_waiting();
  assert(!me_status->is_waiting());
  ASSERT_NOTEQUAL(local_tail->tail_.load(), kNullMcsNodeInt);
  auto ret = me_status->status_.load(std::memory_order_consume);
  if (ret == McsThreadStatus::kGlobalInherited) {
    ASSERT_NOTEQUAL(me_status->inherited_qnode_.load(), kNullMcsNodeInt);
  }
  return ret;
}

inline void CMcsgMcs::regular_acquire(
  uint16_t socket_index,
  uint16_t in_socket_worker_index) {
  // Acquire local, then acquire global only if needed
  McsThreadStatus local_status = regular_local_acquire(socket_index, in_socket_worker_index);
  if (local_status == McsThreadStatus::kGlobalInherited) {
    assert(!statuses_[socket_index][in_socket_worker_index].is_waiting());
    return;
  }

  // alas, global acquire
  assert(local_status == McsThreadStatus::kGlobalContested);
  assert(in_socket_worker_index < kMaxThreadsPerSocket);
  auto* my_pool = &local_locks_[socket_index]->global_qnode_pools_[in_socket_worker_index];
  auto* me_status = &statuses_[socket_index][in_socket_worker_index];
  me_status->set_waiting(std::memory_order_release);

  // only myself sees created_count_. no need for barrier.
  const uint32_t qnode_index = next_global_qnode_index(socket_index, in_socket_worker_index);
  const McsNodeUnion global_qnode_id(socket_index, in_socket_worker_index, qnode_index);
  auto* global_me = &my_pool->pooled_qnodes_[qnode_index % kThreadGlobalQnodePoolSize];
  assert(to_global_qnode(global_qnode_id) == global_me);
  const McsNodeInt global_myself = global_qnode_id.word;
  global_me->store(kNullMcsNodeInt, std::memory_order_release);

  // only myself will see at release, so relaxed
  me_status->inherited_qnode_.store(global_myself, std::memory_order_relaxed);
  me_status->inherit_count_.store(0, std::memory_order_relaxed);

  McsNodeInt my_group_tail = global_myself;
  McsNodeInt prev_tail = kNullMcsNodeInt;
  while (true) {
    if (UNLIKELY(global_tail_.load(std::memory_order_acquire) == kPiMcsNodeInt)) {
      spin_while([this]{ return global_tail_.load(std::memory_order_acquire) == kPiMcsNodeInt; });
    }

    assert(my_group_tail != kPiMcsNodeInt);
    assert(my_group_tail != kNullMcsNodeInt);
    prev_tail = global_tail_.exchange(my_group_tail);
    if (prev_tail == kNullMcsNodeInt) {
      me_status->set_running(std::memory_order_release);
      assert(global_tail_.load() != kNullMcsNodeInt);
      return;
    } else if (prev_tail == kPiMcsNodeInt) {
      my_group_tail = global_tail_.exchange(kPiMcsNodeInt);
      assert(my_group_tail != kPiMcsNodeInt);
      assert(my_group_tail != kNullMcsNodeInt);
      continue;
    } else {
      break;
    }
  }

  assert(prev_tail != global_myself);
  assert(prev_tail != my_group_tail);
  assert(prev_tail != kPiMcsNodeInt);
  assert(prev_tail != kNullMcsNodeInt);
  assert(me_status->is_waiting());

  McsNodeUnion prev_union;
  prev_union.word = prev_tail;
  const uint16_t pred_socket = prev_union.component.socket_;
  const uint16_t pred_thread = prev_union.component.thread_;
  assert(pred_socket < socket_count_);
  assert(pred_thread < in_socket_worker_count_);
  auto* global_predecessor = to_global_qnode(prev_union);
  assert(global_predecessor->load() == kNullMcsNodeInt);
  global_predecessor->store(global_myself, std::memory_order_release);

  me_status->spin_while_waiting();
  assert(!me_status->is_waiting());
}

inline void CMcsgMcs::regular_release_global(
  uint16_t socket_index,
  uint16_t in_socket_worker_index) {
  auto* me_status = &statuses_[socket_index][in_socket_worker_index];
  assert(!me_status->is_waiting());
  const McsNodeInt global_qnode_id = me_status->inherited_qnode_.load(std::memory_order_acquire);

  McsNodeUnion qnode_union;
  qnode_union.word = global_qnode_id;
  // surely my cohort, but might not be myself
  assert(qnode_union.component.socket_ == socket_index);
  auto* global_qnode = to_global_qnode(qnode_union);
  McsNodeInt observed = global_qnode->load(std::memory_order_acquire);
  assert(observed != kPiMcsNodeInt);
  assert(observed != global_qnode_id);
  if (observed == kNullMcsNodeInt) {
    McsNodeInt expected = global_qnode_id;
    if (LIKELY(global_tail_.compare_exchange_strong(expected, kNullMcsNodeInt))) {
      release_global_qnode(qnode_union);
      return;
    }

    assert(expected != kNullMcsNodeInt);
    assert(expected != global_qnode_id);
    assert(expected != kPiMcsNodeInt);  // in MCS-g, guest has no predecessor

    assert(global_tail_.load() != global_qnode_id);
    spin_while([global_qnode]{
      return global_qnode->load(std::memory_order_acquire) == kNullMcsNodeInt;
    });
    observed = global_qnode->load(std::memory_order_acquire);
  }

  assert(observed != kPiMcsNodeInt);
  assert(observed != global_qnode_id);
  assert(observed != kNullMcsNodeInt);

  assert(!statuses_[socket_index][in_socket_worker_index].is_waiting());

  McsNodeUnion successor_union;
  successor_union.word = observed;
  const uint16_t socket = successor_union.component.socket_;
  const uint16_t thread = successor_union.component.thread_;
  assert(socket != socket_index || thread != in_socket_worker_index);
  auto* successor_status = &statuses_[socket][thread];
  assert(successor_status->is_waiting());
  successor_status->set_running(std::memory_order_release);

  release_global_qnode(qnode_union);
}

inline void CMcsgMcs::regular_release(
  uint16_t socket_index,
  uint16_t in_socket_worker_index) {

  auto* buddy_qnodes = qnodes_[socket_index];
  auto* local_me = &buddy_qnodes[in_socket_worker_index].local_node_;
  auto* me_status = &statuses_[socket_index][in_socket_worker_index];
  auto* local_lock = local_locks_[socket_index];
  assert(!me_status->is_waiting());
  const McsNodeInt local_myself = McsNodeUnion(socket_index, in_socket_worker_index).word;

  // Release local, then release global only if needed
  McsNodeInt my_node = local_me->load(std::memory_order_acquire);
  assert(my_node != local_myself);
  if (my_node == kNullMcsNodeInt) {
    McsNodeInt expected = local_myself;
    if (local_lock->tail_.compare_exchange_strong(expected, kNullMcsNodeInt)) {
      // definitely no inheritance
      regular_release_global(socket_index, in_socket_worker_index);
      return;
    }

    assert(expected != kNullMcsNodeInt);
    assert(expected != local_myself);

    spin_while([local_me]{ return local_me->load(std::memory_order_acquire) == kNullMcsNodeInt; });
    my_node = local_me->load(std::memory_order_acquire);
  }

  assert(my_node != kNullMcsNodeInt);

  assert(local_lock->tail_.load() != kNullMcsNodeInt);
  assert(!me_status->is_waiting());

  McsNodeUnion my_node_union;
  my_node_union.word = my_node;
  const uint16_t socket = my_node_union.component.socket_;
  const uint16_t thread = my_node_union.component.thread_;
  assert(my_node_union.component.qnode_index_ == 0);
  assert(socket == socket_index);
  assert(thread < in_socket_worker_count_);
  assert(thread != in_socket_worker_index);
  auto* successor_status = &statuses_[socket][thread];
  assert(successor_status->is_waiting());

  // Should the local successor inherit it?
  uint32_t count = me_status->inherit_count_.load(std::memory_order_relaxed);  // just a hint.
  if (count >= kCMcsgMcsMaxInheritance) {
    // we have been holding it too long. Let's release the global lock.
    regular_release_global(socket_index, in_socket_worker_index);
    successor_status->inherit_count_.store(0, std::memory_order_release);
    successor_status->inherited_qnode_.store(kNullMcsNodeInt, std::memory_order_release);
    successor_status->status_.store(McsThreadStatus::kGlobalContested, std::memory_order_release);
  } else {
    // In this case, the successor inherits my global lock. Leave it locked.
    const McsNodeInt global_qnode_id = me_status->inherited_qnode_.load(std::memory_order_acquire);
    successor_status->inherit_count_.store(count + 1U, std::memory_order_release);
    successor_status->inherited_qnode_.store(global_qnode_id, std::memory_order_release);
    successor_status->status_.store(McsThreadStatus::kGlobalInherited, std::memory_order_release);
  }
}

inline void CMcsgMcs::guest_acquire(uint32_t /*guest_fingerprint*/) {
  spin_while([this]{
    McsNodeInt old_int = kNullMcsNodeInt;
    return !global_tail_.compare_exchange_weak(old_int, kPiMcsNodeInt);
  });
  assert(global_tail_.load() != kNullMcsNodeInt);
}

inline void CMcsgMcs::guest_release(uint32_t /*guest_fingerprint*/) {
  spin_while([this]{
    McsNodeInt old_int = kPiMcsNodeInt;
    return !global_tail_.compare_exchange_weak(old_int, kNullMcsNodeInt);
  });
}

inline std::atomic< McsNodeInt >* CMcsgMcs::to_global_qnode(McsNodeUnion id)  {
  assert(id.component.socket_ < socket_count_);
  assert(id.component.thread_ < in_socket_worker_count_);
  auto* pool = &local_locks_[id.component.socket_]->global_qnode_pools_[id.component.thread_];
  uint32_t qnode_index_mod = id.component.qnode_index_ % kThreadGlobalQnodePoolSize;
  return &pool->pooled_qnodes_[qnode_index_mod];
}


inline void CMcsgMcs::release_global_qnode(McsNodeUnion id)  {
  assert(id.component.socket_ < socket_count_);
  assert(id.component.thread_ < in_socket_worker_count_);
  auto* pool = &local_locks_[id.component.socket_]->global_qnode_pools_[id.component.thread_];
  uint32_t qnode_index_mode = id.component.qnode_index_ % kThreadGlobalQnodePoolSize;
  pool->pooled_qnodes_[qnode_index_mode].store(kMcsUnusedQnode, std::memory_order_release);
}

inline uint32_t CMcsgMcs::next_global_qnode_index(
  uint16_t socket_index,
  uint16_t in_socket_worker_index) {
  auto* pool = &local_locks_[socket_index]->global_qnode_pools_[in_socket_worker_index];
  uint32_t next = pool->next_qnode_index_;
  while (UNLIKELY(pool->pooled_qnodes_[next].load(std::memory_order_relaxed) != kMcsUnusedQnode)) {
    ++next;
    if (UNLIKELY(next >= kThreadGlobalQnodePoolSize)) {
      next -= kThreadGlobalQnodePoolSize;
    }
  }
  assert(pool->pooled_qnodes_[next].load() == kMcsUnusedQnode);
  pool->next_qnode_index_ = next;  // for next invocation
  return next;
}

#endif  // C_MCSG_MCS_HPP_
