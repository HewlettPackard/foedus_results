/*
 * Copyright (c) 2014-2015, Hewlett-Packard Development Company, LP.
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details. You should have received a copy of the GNU General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * HP designates this particular file as subject to the "Classpath" exception
 * as provided by HP in the LICENSE.txt file that accompanied this code.
 */
#ifndef K42_HPP_
#define K42_HPP_

#include <numa.h>

#include <atomic>
#include <cassert>
#include <cstring>
#include <memory>

#include "lock_api.hpp"

/**
 * Implements K42's version of MCS lock, which uses a standard interface.
 * Users don't need to provide a QNode.
 *
 * Compared to other implementations (e.g., MCS) this one is a bit special,
 * because we manipulate pointers directly, instead of going through a proxy
 * of socket/thread index arrays. Since K42-MCS uses QNodes allocated on the
 * stack, it cannot be used in multi-process shared memory environments like
 * our implementation of MCS/MCSg.
 */

struct K42Node {
  std::atomic< K42Node* > next_;
  std::atomic< K42Node* > tail_;
  char filler_[256 - sizeof(next_) - sizeof(tail_)];

  K42Node() {
    next_.store(NULL);
    tail_.store(NULL);
  }

  K42Node(K42Node* next, K42Node* tail) {
    next_.store(next);
    tail_.store(tail);
  }
};

constexpr K42Node* kK42Waiting = (K42Node*)(1);

struct K42 {
  /** @returns a unique name that describes the lock algorithm */
  static std::string name() { return "k42"; }

  /**
   * Must have a constructor without arguments.
   */
  K42() {}

  /** We recommend disabling copy constructor to prevent misuse */
  K42(const K42& other) = delete;

  /**
   * Do whatever initialization required to run the experiment.
   * @return will be the return value of main() unless it's 0 (no error).
   */
  int init(
    uint16_t /* socket_count */,
    uint16_t /* in_socket_worker_count */,
    uint32_t /* total_worker_count */) {
    return 0;
  }

  /**
   * Do whatever un-initialization after the experiment.
   * @return will be the return value of main() unless it's 0 (no error).
   */
  int uninit() {
    return 0;
  }

  /**
   * Unconditional lock-acquire for regular user with the given indexes.
   */
  void regular_acquire(
    uint16_t socket_index,
    uint16_t in_socket_worker_index) __attribute__((always_inline));

  /**
   * Lock-release for regular user.
   */
  void regular_release(
    uint16_t socket_index,
    uint16_t in_socket_worker_index) __attribute__((always_inline));

  /**
   * Unconditional lock-acquire for guest user with the given fingerprint
   * (which semi-identifies the guest thread. it might not be unique).
   */
  void guest_acquire(
    uint32_t guest_fingerprint) __attribute__((always_inline));

  /**
   * Lock-release for guest user.
   */
  void guest_release(
    uint32_t guest_fingerprint) __attribute__((always_inline));

  /** Print out whatever statistics collected during the experiment. */
  void print_stat();

  K42Node lock_;
};

inline void K42::regular_acquire(
  uint16_t /* socket_index */,
  uint16_t /* in_socket_worker_index */) {
  guest_acquire(0);
}

inline void K42::regular_release(
  uint16_t /* socket_index */,
  uint16_t /* in_socket_worker_index */) {
  guest_release(0);
}

inline void K42::guest_acquire(uint32_t /*guest_fingerprint*/) {
retry:
  K42Node* pred = lock_.tail_.load(std::memory_order_acquire);
  if (pred == NULL) {
    K42Node* expected = NULL;
    if (!lock_.tail_.compare_exchange_weak(expected, &lock_)) {
      goto retry;
    }
  } else {
    K42Node me(NULL, kK42Waiting);
    if (!lock_.tail_.compare_exchange_weak(pred, &me)) {
      goto retry;
    }
    pred->next_.store(&me, std::memory_order_release);
    while (me.tail_.load(std::memory_order_acquire) == kK42Waiting) {}
    // Now I have the lock. Capture the successor (if any) and send
    // it to the lock's next field. After this my QNode can be discarded.
    K42Node* successor = me.next_.load(std::memory_order_acquire);
    if (successor) {
      assert(successor && successor != kK42Waiting);
      lock_.next_.store(successor, std::memory_order_release);
    } else {
      // Make the lock point to itself
      K42Node* expected = &me;
      lock_.next_.store(NULL, std::memory_order_release);
      if (!lock_.tail_.compare_exchange_weak(expected, &lock_)) {
        // Somebody else got in, but it should queue up after me
        do {
          successor = me.next_.load(std::memory_order_acquire);
        } while (!successor);
        assert(successor && successor != kK42Waiting);
        lock_.next_.store(successor, std::memory_order_release);
      }
    }
  }
}

inline void K42::guest_release(uint32_t /*guest_fingerprint*/) {
  auto* succ = lock_.next_.load(std::memory_order_acquire);
  if (!succ) {
    K42Node* expected = &lock_;
    if (lock_.tail_.compare_exchange_weak(expected, NULL)) {
      return;
    } else {
      do {
        succ = lock_.next_.load(std::memory_order_acquire);
      } while (!succ);
    }
  }
  assert(succ);
  succ->tail_.store(NULL, std::memory_order_release);
}
#endif  // K42_HPP_
