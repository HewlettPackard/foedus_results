hstore_hosts="localhost:0:0-7"
hstore_client_memory="512"
hstore_site_memory="8192"
hstore_global_memory="2048"
hstore_client_threads_per_host="50"
machine_name="Hideaki's Z820"
machine_shortname="z820"
. run_hstore_common.sh
