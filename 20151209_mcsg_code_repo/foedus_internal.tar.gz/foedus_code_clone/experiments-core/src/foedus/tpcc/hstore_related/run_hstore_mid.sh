hstore_hosts="localhost:0:0-5;localhost:1:6-11;localhost:2:12-17;localhost:3:18-23"
hstore_client_memory="2048"
hstore_site_memory="30720"
hstore_global_memory="20480"
hstore_client_threads_per_host="150"
machine_name="Mid-Low-Server"
machine_shortname="mid"
. run_hstore_common.sh
